// ĐỀ THI MẪU 3
#include <iostream>
#include <fstream>
#include <cstring>
#include <cctype>
using namespace std;

// ===== CÂU 1: KIỂM TRA SỐ ĐỐI XỨNG =====
bool laSoDoiXung(long long n) {
    if(n < 0) return false;
    
    long long goc = n;
    long long daoNguoc = 0;
    
    while(n > 0) {
        daoNguoc = daoNguoc * 10 + n % 10;
        n /= 10;
    }
    
    return goc == daoNguoc;
}

// ===== CÂU 2: IN N SỐ NGUYÊN TỐ ĐẦU TIÊN =====
bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

void inNSoNguyenTo(int n) {
    cout << n << " so nguyen to dau tien: ";
    
    int dem = 0;
    int soHienTai = 2;
    
    while(dem < n) {
        if(laSNT(soHienTai)) {
            cout << soHienTai << " ";
            dem++;
        }
        soHienTai++;
    }
    cout << endl;
}

// ===== CÂU 3: MẢNG =====
void nhapMang(int a[], int &n) {
    do {
        cout << "Nhap so phan tu: ";
        cin >> n;
    } while(n <= 0 || n > 1000);
    
    for(int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
}

void xuatMang(int a[], int n) {
    cout << "Mang: ";
    for(int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

int viTriLeMin(int a[], int n) {
    int minLe = -1;
    int viTri = -1;
    
    for(int i = 0; i < n; i++) {
        if(a[i] % 2 != 0) { // Số lẻ
            if(minLe == -1 || a[i] < minLe) {
                minLe = a[i];
                viTri = i;
            }
        }
    }
    
    return viTri;
}

void sapXepGiamDan(int a[], int n) {
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) {
            if(a[i] < a[j]) {
                swap(a[i], a[j]);
            }
        }
    }
}

void inMangConTangDaiNhat(int a[], int n) {
    int maxLen = 1, currentLen = 1;
    int maxStart = 0, currentStart = 0;
    
    for(int i = 1; i < n; i++) {
        if(a[i] > a[i-1]) {
            currentLen++;
        } else {
            if(currentLen > maxLen) {
                maxLen = currentLen;
                maxStart = currentStart;
            }
            currentLen = 1;
            currentStart = i;
        }
    }
    
    // Kiểm tra lần cuối
    if(currentLen > maxLen) {
        maxLen = currentLen;
        maxStart = currentStart;
    }
    
    cout << "Mang con tang dai nhat (do dai " << maxLen << "): ";
    for(int i = maxStart; i < maxStart + maxLen; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

// ===== CÂU 4: TÁCH NGUYÊN ÂM VÀ PHỤ ÂM =====
bool laNguyenAm(char c) {
    c = tolower(c);
    return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
}

bool laChuCai(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

void tachNguyenAmPhuAm(char s[]) {
    char phuAm[1000], nguyenAm[1000];
    int idxPA = 0, idxNA = 0;
    
    for(int i = 0; i < strlen(s); i++) {
        if(laChuCai(s[i])) {
            if(laNguyenAm(s[i])) {
                nguyenAm[idxNA++] = tolower(s[i]);
            } else {
                phuAm[idxPA++] = tolower(s[i]);
            }
        }
    }
    
    phuAm[idxPA] = '\0';
    nguyenAm[idxNA] = '\0';
    
    cout << "Ket qua: " << phuAm << " " << nguyenAm << endl;
}

// ===== CÂU 5: ĐỌC FILE TUYỂN SINH =====
struct ThiSinh {
    char maTS[10];
    float mon1, mon2, mon3;
};

void docFileTuyenSinh() {
    ifstream fileIn("nguon.txt");
    ofstream fileOut("dich.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file nguon.txt!" << endl;
        return;
    }
    
    if(!fileOut) {
        cout << "Khong the tao file dich.txt!" << endl;
        return;
    }
    
    ThiSinh ts;
    int tsDau = 0;
    
    while(fileIn >> ts.maTS >> ts.mon1 >> ts.mon2 >> ts.mon3) {
        float tong = ts.mon1 + ts.mon2 + ts.mon3;
        
        // Kiểm tra điều kiện đậu
        if(tong >= 15 && ts.mon1 >= 1 && ts.mon2 >= 1 && ts.mon3 >= 1) {
            fileOut << ts.maTS << " " << ts.mon1 << " " << ts.mon2 << " " << ts.mon3 << endl;
            tsDau++;
        }
    }
    
    fileIn.close();
    fileOut.close();
    
    cout << "So thi sinh dau: " << tsDau << endl;
    cout << "Da luu vao file dich.txt" << endl;
}

// ===== MENU =====
void menu() {
    cout << "\n===== DE THI MAU 3 =====" << endl;
    cout << "1. Cau 1: Kiem tra so doi xung" << endl;
    cout << "2. Cau 2: In n so nguyen to dau tien" << endl;
    cout << "3. Cau 3a: Nhap/Xuat mang" << endl;
    cout << "4. Cau 3c: Tim vi tri so le nho nhat" << endl;
    cout << "5. Cau 3d: Sap xep giam dan" << endl;
    cout << "6. Cau 3e: In mang con tang dai nhat" << endl;
    cout << "7. Cau 4: Tach nguyen am va phu am" << endl;
    cout << "8. Cau 5: Doc file tuyen sinh" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int a[1000], n = 0;
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        cin.ignore();
        
        switch(luaChon) {
            case 1: {
                long long num;
                cout << "Nhap so nguyen: ";
                cin >> num;
                if(laSoDoiXung(num)) {
                    cout << num << " -> Doi xung" << endl;
                } else {
                    cout << num << " -> Khong doi xung" << endl;
                }
                break;
            }
            case 2: {
                int n;
                cout << "Nhap n: ";
                cin >> n;
                inNSoNguyenTo(n);
                break;
            }
            case 3:
                nhapMang(a, n);
                xuatMang(a, n);
                break;
            case 4: {
                int viTri = viTriLeMin(a, n);
                if(viTri == -1) {
                    cout << "Khong co so le trong mang!" << endl;
                } else {
                    cout << "Vi tri so le nho nhat: " << viTri << " (gia tri: " << a[viTri] << ")" << endl;
                }
                break;
            }
            case 5:
                sapXepGiamDan(a, n);
                cout << "Da sap xep giam dan!" << endl;
                xuatMang(a, n);
                break;
            case 6:
                inMangConTangDaiNhat(a, n);
                break;
            case 7: {
                char s[1000];
                cout << "Nhap chuoi: ";
                cin.getline(s, 1000);
                tachNguyenAmPhuAm(s);
                break;
            }
            case 8:
                docFileTuyenSinh();
                break;
            case 0:
                cout << "Tam biet!" << endl;
                break;
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

