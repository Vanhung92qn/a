// BÀI 5: XÁC ĐỊNH LOẠI TAM GIÁC
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

// Hàm tính khoảng cách giữa 2 điểm
float khoangCach(float x1, float y1, float x2, float y2) {
    return sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
}

int main() {
    float xA, yA, xB, yB, xC, yC;
    
    cout << "Nhap toa do diem A (x y): ";
    cin >> xA >> yA;
    cout << "Nhap toa do diem B (x y): ";
    cin >> xB >> yB;
    cout << "Nhap toa do diem C (x y): ";
    cin >> xC >> yC;
    
    // Tính độ dài 3 cạnh
    float AB = khoangCach(xA, yA, xB, yB);
    float BC = khoangCach(xB, yB, xC, yC);
    float CA = khoangCach(xC, yC, xA, yA);
    
    cout << fixed << setprecision(2);
    cout << "\nDo dai canh AB = " << AB << endl;
    cout << "Do dai canh BC = " << BC << endl;
    cout << "Do dai canh CA = " << CA << endl;
    
    // Kiểm tra điều kiện tam giác
    if (AB + BC <= CA || AB + CA <= BC || BC + CA <= AB) {
        cout << "\nKhong phai tam giac!" << endl;
        return 0;
    }
    
    // Sắp xếp 3 cạnh để dễ kiểm tra
    float a = AB, b = BC, c = CA;
    if (a < b) swap(a, b);
    if (a < c) swap(a, c);
    if (b < c) swap(b, c);
    // Bây giờ: a >= b >= c
    
    const float epsilon = 0.0001; // Sai số để so sánh float
    
    // Kiểm tra tam giác đều
    if (fabs(AB - BC) < epsilon && fabs(BC - CA) < epsilon) {
        cout << "\nDay la tam giac DEU!" << endl;
    }
    // Kiểm tra tam giác vuông cân
    else if (fabs(a*a - b*b - c*c) < epsilon && fabs(b - c) < epsilon) {
        cout << "\nDay la tam giac VUONG CAN!" << endl;
    }
    // Kiểm tra tam giác vuông
    else if (fabs(a*a - b*b - c*c) < epsilon) {
        cout << "\nDay la tam giac VUONG!" << endl;
    }
    // Kiểm tra tam giác cân
    else if (fabs(AB - BC) < epsilon || fabs(BC - CA) < epsilon || fabs(CA - AB) < epsilon) {
        cout << "\nDay la tam giac CAN!" << endl;
    }
    // Tam giác thường
    else {
        cout << "\nDay la tam giac THUONG!" << endl;
    }
    
    return 0;
}

