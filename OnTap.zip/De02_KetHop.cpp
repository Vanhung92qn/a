// ĐỀ 2: BÀI TẬP KẾT HỢP
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <cmath>
using namespace std;

// ===== CÂU 1: NGÀY TIẾP THEO =====
bool laNamNhuan(int nam) {
    return (nam % 400 == 0) || (nam % 4 == 0 && nam % 100 != 0);
}

int soNgayTrongThang(int thang, int nam) {
    int ngay[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if(thang == 2 && laNamNhuan(nam)) return 29;
    return ngay[thang];
}

void cau1() {
    int ngay, thang, nam;
    cout << "Nhap ngay/thang/nam (dd mm yyyy): ";
    cin >> ngay >> thang >> nam;
    
    if(nam < 2000 || thang < 1 || thang > 12 || ngay < 1 || ngay > soNgayTrongThang(thang, nam)) {
        cout << "Ngay khong hop le!" << endl;
        return;
    }
    
    // Tính ngày tiếp theo
    ngay++;
    if(ngay > soNgayTrongThang(thang, nam)) {
        ngay = 1;
        thang++;
        if(thang > 12) {
            thang = 1;
            nam++;
        }
    }
    
    cout << "Ngay tiep theo la: " << ngay << "/" << thang << "/" << nam << endl;
}

// ===== CÂU 2: TÍNH TỔNG S = 1 - 1/2^2 + 1/3^3 - ... =====
double tinhTongS(int n) {
    double tong = 0;
    for(int i = 1; i <= n; i++) {
        int dau = (i % 2 == 1) ? 1 : -1;
        tong += dau / pow(i, i);
    }
    return tong;
}

void cau2() {
    int n;
    do {
        cout << "Nhap n nguyen duong: ";
        cin >> n;
    } while(n <= 0);
    
    cout << fixed << setprecision(10);
    cout << "S(" << n << ") = " << tinhTongS(n) << endl;
}

// ===== CÂU 3: MẢNG =====
const int MAX = 1000;
int M[MAX], n;

void nhapMang() {
    cout << "Nhap so phan tu: ";
    cin >> n;
    for(int i = 0; i < n; i++) {
        cout << "M[" << i << "] = ";
        cin >> M[i];
    }
}

void xuatMang() {
    cout << "Mang: ";
    for(int i = 0; i < n; i++) {
        cout << M[i] << " ";
    }
    cout << endl;
}

// a. Loại phần tử trùng
void loaiPhanTuTrung() {
    int j = 0;
    for(int i = 0; i < n; i++) {
        bool trung = false;
        for(int k = 0; k < j; k++) {
            if(M[i] == M[k]) {
                trung = true;
                break;
            }
        }
        if(!trung) {
            M[j++] = M[i];
        }
    }
    n = j;
    cout << "Da loai cac phan tu trung!" << endl;
}

// b. Sắp xếp tăng dần
void sapXepTangDan() {
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) {
            if(M[i] > M[j]) {
                swap(M[i], M[j]);
            }
        }
    }
    cout << "Da sap xep tang dan!" << endl;
}

// c. Chèn tăng (vào mảng đã sắp xếp)
void chenTang() {
    int x;
    cout << "Nhap gia tri can chen: ";
    cin >> x;
    
    // Tìm vị trí chèn
    int viTri = n;
    for(int i = 0; i < n; i++) {
        if(M[i] > x) {
            viTri = i;
            break;
        }
    }
    
    // Dịch các phần tử
    for(int i = n; i > viTri; i--) {
        M[i] = M[i-1];
    }
    
    M[viTri] = x;
    n++;
    
    cout << "Da chen " << x << " vao vi tri " << viTri << endl;
}

// d. Loại giá trị x
void loaiGiaTri() {
    int x;
    cout << "Nhap gia tri can loai: ";
    cin >> x;
    
    int j = 0;
    int dem = 0;
    for(int i = 0; i < n; i++) {
        if(M[i] != x) {
            M[j++] = M[i];
        } else {
            dem++;
        }
    }
    n = j;
    
    cout << "Da loai " << dem << " phan tu co gia tri " << x << endl;
}

// ===== CÂU 4: ĐẾM SỐ LẦN XUẤT HIỆN CỦA MỖI KÝ TỰ =====
void cau4() {
    cin.ignore();
    string s;
    cout << "Nhap chuoi: ";
    getline(cin, s);
    
    cout << "\nSo lan xuat hien cua moi ky tu:" << endl;
    
    // Đánh dấu ký tự đã đếm
    bool daDem[256] = {false};
    
    for(int i = 0; i < s.length(); i++) {
        if(!daDem[(int)s[i]]) {
            int dem = 0;
            for(int j = 0; j < s.length(); j++) {
                if(s[j] == s[i]) {
                    dem++;
                }
            }
            
            cout << "'" << s[i] << "' : " << dem << " lan" << endl;
            daDem[(int)s[i]] = true;
        }
    }
}

// ===== CÂU 5: ĐỌC FILE SÁCH =====
struct Sach {
    string loaiSach;
    int namXB;
    int soTrang;
};

void cau5() {
    ifstream fileIn("Input_Sach.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file Input_Sach.txt!" << endl;
        return;
    }
    
    int soSach;
    fileIn >> soSach;
    
    vector<Sach> dsSach;
    
    for(int i = 0; i < soSach; i++) {
        Sach s;
        fileIn >> s.loaiSach >> s.namXB >> s.soTrang;
        dsSach.push_back(s);
    }
    
    fileIn.close();
    
    // Hiển thị danh sách
    cout << "\n===== DANH SACH SACH =====" << endl;
    cout << "Loai sach\tNam XB\tSo trang" << endl;
    cout << "-------------------------------------" << endl;
    
    for(int i = 0; i < dsSach.size(); i++) {
        cout << dsSach[i].loaiSach << "\t"
             << dsSach[i].namXB << "\t"
             << dsSach[i].soTrang << endl;
    }
    
    // Lọc sách xuất bản trước 2015
    ofstream fileOut("Output_Sach.txt");
    
    if(!fileOut) {
        cout << "Khong the tao file Output_Sach.txt!" << endl;
        return;
    }
    
    cout << "\n===== SACH XUAT BAN TRUOC 2015 =====" << endl;
    int dem = 0;
    
    for(int i = 0; i < dsSach.size(); i++) {
        if(dsSach[i].namXB < 2015) {
            fileOut << dsSach[i].loaiSach << " " 
                    << dsSach[i].namXB << " "
                    << dsSach[i].soTrang << endl;
            
            cout << dsSach[i].loaiSach << " - Nam: " 
                 << dsSach[i].namXB << endl;
            dem++;
        }
    }
    
    fileOut.close();
    
    cout << "\nTong: " << dem << " cuon sach" << endl;
    cout << "Da ghi vao file Output_Sach.txt" << endl;
}

// ===== MENU =====
void menu() {
    cout << "\n===== DE 2: BAI TAP KET HOP =====" << endl;
    cout << "1. Cau 1: Ngay tiep theo" << endl;
    cout << "2. Cau 2: Tinh tong S" << endl;
    cout << "3. Cau 3: Nhap mang" << endl;
    cout << "4. Cau 3: Xuat mang" << endl;
    cout << "5. Cau 3a: Loai phan tu trung" << endl;
    cout << "6. Cau 3b: Sap xep tang dan" << endl;
    cout << "7. Cau 3c: Chen tang" << endl;
    cout << "8. Cau 3d: Loai gia tri x" << endl;
    cout << "9. Cau 4: Dem so lan xuat hien ky tu" << endl;
    cout << "10. Cau 5: Doc file sach" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1: cau1(); break;
            case 2: cau2(); break;
            case 3: nhapMang(); break;
            case 4: xuatMang(); break;
            case 5: loaiPhanTuTrung(); xuatMang(); break;
            case 6: sapXepTangDan(); xuatMang(); break;
            case 7: chenTang(); xuatMang(); break;
            case 8: loaiGiaTri(); xuatMang(); break;
            case 9: cau4(); break;
            case 10: cau5(); break;
            case 0: cout << "Tam biet!" << endl; break;
            default: cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

