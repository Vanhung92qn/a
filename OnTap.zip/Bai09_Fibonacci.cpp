// BÀI 9: TÌM SỐ FIBONACCI THỨ N
#include <iostream>
using namespace std;

// Phương pháp 1: Đệ quy (chậm với n lớn)
long long fibonacciDeQuy(int n) {
    if (n <= 1) return n;
    return fibonacciDeQuy(n-1) + fibonacciDeQuy(n-2);
}

// Phương pháp 2: Lặp (nhanh hơn, nên dùng)
long long fibonacci(int n) {
    if (n <= 1) return n;
    
    long long f0 = 0, f1 = 1, fn;
    
    for(int i = 2; i <= n; i++) {
        fn = f0 + f1;
        f0 = f1;
        f1 = fn;
    }
    
    return fn;
}

int main() {
    int n;
    
    cout << "Nhap n: ";
    cin >> n;
    
    if(n < 0) {
        cout << "Vui long nhap n >= 0!" << endl;
        return 0;
    }
    
    cout << "So Fibonacci thu " << n << " la: " << fibonacci(n) << endl;
    
    // In ra dãy Fibonacci từ 0 đến n
    cout << "\nDay Fibonacci tu 0 den " << n << ": ";
    for(int i = 0; i <= n; i++) {
        cout << fibonacci(i) << " ";
    }
    cout << endl;
    
    return 0;
}

