// ĐỌC FILE SỐ NGUYÊN VÀ TÍNH TRUNG BÌNH CỘNG
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

int main() {
    ifstream fileIn("SoNguyen.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file SoNguyen.txt!" << endl;
        return 1;
    }
    
    int so;
    int dem = 0;
    int tong = 0;
    
    cout << "Cac so trong file: ";
    while(fileIn >> so) {
        cout << so << " ";
        tong += so;
        dem++;
    }
    
    fileIn.close();
    
    if(dem == 0) {
        cout << "\nFile rong!" << endl;
        return 0;
    }
    
    double trungBinh = (double)tong / dem;
    
    cout << fixed << setprecision(2);
    cout << "\n\nTong: " << tong << endl;
    cout << "So phan tu: " << dem << endl;
    cout << "Trung binh cong: " << trungBinh << endl;
    
    return 0;
}

