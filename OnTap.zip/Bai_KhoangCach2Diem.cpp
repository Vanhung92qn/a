// CÂU 4: ĐỌC FILE TỌA ĐỘ 2 ĐIỂM, TÍNH KHOẢNG CÁCH VÀ GHI FILE
#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

struct Diem {
    double x, y;
};

// Hàm tính khoảng cách giữa 2 điểm
double tinhKhoangCach(Diem A, Diem B) {
    return sqrt((B.x - A.x) * (B.x - A.x) + (B.y - A.y) * (B.y - A.y));
}

int main() {
    // Câu 4a: Đọc dữ liệu từ file a.txt
    ifstream fileIn("a.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file a.txt!" << endl;
        cout << "Vui long tao file a.txt voi dinh dang:" << endl;
        cout << "x1 y1" << endl;
        cout << "x2 y2" << endl;
        return 1;
    }
    
    Diem A, B;
    
    // Đọc tọa độ điểm A (dòng 1)
    fileIn >> A.x >> A.y;
    
    // Đọc tọa độ điểm B (dòng 2)
    fileIn >> B.x >> B.y;
    
    fileIn.close();
    
    // Hiển thị thông tin
    cout << fixed << setprecision(4);
    cout << "===== THONG TIN 2 DIEM =====" << endl;
    cout << "Diem A: (" << A.x << ", " << A.y << ")" << endl;
    cout << "Diem B: (" << B.x << ", " << B.y << ")" << endl;
    
    // Tính khoảng cách
    double khoangCach = tinhKhoangCach(A, B);
    
    cout << "\nKhoang cach giua 2 diem A va B: " << khoangCach << endl;
    
    // Câu 4b: Ghi kết quả vào file b.txt
    ofstream fileOut("b.txt");
    
    if(!fileOut) {
        cout << "\nKhong the tao file b.txt!" << endl;
        return 1;
    }
    
    fileOut << fixed << setprecision(4);
    fileOut << "Toa do diem A: (" << A.x << ", " << A.y << ")" << endl;
    fileOut << "Toa do diem B: (" << B.x << ", " << B.y << ")" << endl;
    fileOut << "Khoang cach: " << khoangCach << endl;
    
    fileOut.close();
    
    cout << "\nDa ghi ket qua vao file b.txt!" << endl;
    
    return 0;
}

