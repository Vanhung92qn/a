// BÀI: IN RA CÁC SỐ NGUYÊN TỐ NHỎ HỎN N
#include <iostream>
using namespace std;

// Hàm kiểm tra số nguyên tố
bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

int main() {
    int n;
    
    cout << "Nhap n: ";
    cin >> n;
    
    cout << "Cac so nguyen to nho hon " << n << " la:" << endl;
    
    int dem = 0;
    for(int i = 2; i < n; i++) {
        if(laSNT(i)) {
            cout << i << " ";
            dem++;
            if(dem % 20 == 0) cout << endl; // Xuống dòng sau 20 số
        }
    }
    
    cout << "\n\nTong cong co " << dem << " so nguyen to nho hon " << n << endl;
    
    return 0;
}

