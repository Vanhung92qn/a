// BÀI: TÍNH TIỀN ĐIỆN LŨY TIẾN
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int soDauKy, soCuoiKy;
    float m1, m2, m3; // Đơn giá các mức
    
    cout << "===== TINH TIEN DIEN =====" << endl;
    cout << "Nhap chi so dau ky: ";
    cin >> soDauKy;
    cout << "Nhap chi so cuoi ky: ";
    cin >> soCuoiKy;
    
    cout << "\nNhap don gia muc 1 (100 so dau): ";
    cin >> m1;
    cout << "Nhap don gia muc 2 (100 so tiep): ";
    cin >> m2;
    cout << "Nhap don gia muc 3 (phan con lai): ";
    cin >> m3;
    
    int soTieuThu = soCuoiKy - soDauKy;
    
    if(soTieuThu < 0) {
        cout << "\nChi so cuoi ky phai lon hon chi so dau ky!" << endl;
        return 0;
    }
    
    float tienDien = 0;
    
    // Tính tiền theo lũy tiến
    if(soTieuThu <= 100) {
        tienDien = soTieuThu * m1;
    } else if(soTieuThu <= 200) {
        tienDien = 100 * m1 + (soTieuThu - 100) * m2;
    } else {
        tienDien = 100 * m1 + 100 * m2 + (soTieuThu - 200) * m3;
    }
    
    cout << fixed << setprecision(2);
    cout << "\n===== KET QUA =====" << endl;
    cout << "So dien tieu thu: " << soTieuThu << " kWh" << endl;
    cout << "Tien dien phai tra: " << tienDien << " VND" << endl;
    
    return 0;
}

