// ĐỀ THI MẪU 1
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;

// ===== CÂU 1: TÍNH TỔNG S(n) = 1 - 1/2! + 1/3! - ... =====
long long giaiThua(int x) {
    long long ketQua = 1;
    for(int i = 1; i <= x; i++) {
        ketQua *= i;
    }
    return ketQua;
}

int nhapNguyenDuong() {
    int n;
    do {
        cout << "Nhap n nguyen duong: ";
        cin >> n;
        if(n <= 0) {
            cout << "Vui long nhap n > 0!" << endl;
        }
    } while(n <= 0);
    return n;
}

double tinhTongS(int n) {
    double tong = 0;
    for(int i = 1; i <= n; i++) {
        int dau = (i % 2 == 1) ? 1 : -1;
        tong += dau * (1.0 / giaiThua(i));
    }
    return tong;
}

// ===== CÂU 3: MẢNG =====
void nhapMang(int a[], int &n) {
    do {
        cout << "Nhap so phan tu: ";
        cin >> n;
    } while(n <= 0 || n > 1000);
    
    for(int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
}

void xuatMang(int a[], int n) {
    cout << "Mang: ";
    for(int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

int tongSoLe(int a[], int n) {
    int tong = 0;
    for(int i = 0; i < n; i++) {
        if(a[i] % 2 != 0) {
            tong += a[i];
        }
    }
    return tong;
}

bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

void sapXepSNTVeCuoi(int a[], int n) {
    int left = 0, right = n - 1;
    
    while(left < right) {
        // Tìm số nguyên tố từ trái
        while(left < n && !laSNT(a[left])) {
            left++;
        }
        
        // Tìm số không phải nguyên tố từ phải
        while(right >= 0 && laSNT(a[right])) {
            right--;
        }
        
        // Hoán đổi
        if(left < right) {
            swap(a[left], a[right]);
            left++;
            right--;
        }
    }
}

// ===== CÂU 4: XÓA KÝ TỰ GIỐNG NHAU LIỀN KỀ =====
void xoaKyTuGiongNhau(char s[]) {
    int j = 0;
    int len = strlen(s);
    
    for(int i = 0; i < len; i++) {
        // Nếu ký tự hiện tại khác ký tự trước đó hoặc là ký tự đầu tiên
        if(j == 0 || s[i] != s[j-1]) {
            s[j++] = s[i];
        }
    }
    
    s[j] = '\0';
}

// ===== CÂU 5: ĐỌC FILE VÀ TÍNH TRUNG BÌNH =====
void docFileTinhTrungBinh() {
    ifstream fileIn("SoNguyen.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file SoNguyen.txt!" << endl;
        return;
    }
    
    int so, dem = 0, tong = 0;
    
    while(fileIn >> so) {
        tong += so;
        dem++;
    }
    
    fileIn.close();
    
    if(dem == 0) {
        cout << "File rong!" << endl;
        return;
    }
    
    cout << fixed << setprecision(2);
    cout << "Trung binh cong: " << (double)tong / dem << endl;
}

// ===== MENU =====
void menu() {
    cout << "\n===== DE THI MAU 1 =====" << endl;
    cout << "1. Cau 1: Tinh tong S(n)" << endl;
    cout << "2. Cau 3a: Nhap mang" << endl;
    cout << "3. Cau 3b: Xuat mang" << endl;
    cout << "4. Cau 3c: Tinh tong so le" << endl;
    cout << "5. Cau 3d: Dua SNT ve cuoi" << endl;
    cout << "6. Cau 4: Xoa ky tu giong nhau lien ke" << endl;
    cout << "7. Cau 5: Doc file tinh trung binh" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int a[1000], n = 0;
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        cin.ignore();
        
        switch(luaChon) {
            case 1: {
                int n = nhapNguyenDuong();
                cout << fixed << setprecision(10);
                cout << "S(" << n << ") = " << tinhTongS(n) << endl;
                break;
            }
            case 2:
                nhapMang(a, n);
                break;
            case 3:
                xuatMang(a, n);
                break;
            case 4:
                cout << "Tong cac so le: " << tongSoLe(a, n) << endl;
                break;
            case 5:
                sapXepSNTVeCuoi(a, n);
                cout << "Da sap xep!" << endl;
                xuatMang(a, n);
                break;
            case 6: {
                char s[1000];
                cout << "Nhap chuoi: ";
                cin.getline(s, 1000);
                xoaKyTuGiongNhau(s);
                cout << "Ket qua: " << s << endl;
                break;
            }
            case 7:
                docFileTinhTrungBinh();
                break;
            case 0:
                cout << "Tam biet!" << endl;
                break;
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

