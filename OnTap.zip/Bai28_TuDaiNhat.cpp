// BÀI 28: TÌM TỪ DÀI NHẤT TRONG CHUỖI
#include <iostream>
#include <cstring>
using namespace std;

void timTuDaiNhat(char s[]) {
    int maxLen = 0;
    int maxStart = 0;
    int currentLen = 0;
    int currentStart = 0;
    bool trongTu = false;
    
    for(int i = 0; i <= strlen(s); i++) {
        if(i < strlen(s) && s[i] != ' ' && s[i] != '\t' && s[i] != '\n') {
            if(!trongTu) {
                currentStart = i;
                currentLen = 0;
                trongTu = true;
            }
            currentLen++;
        } else {
            if(trongTu && currentLen > maxLen) {
                maxLen = currentLen;
                maxStart = currentStart;
            }
            trongTu = false;
            currentLen = 0;
        }
    }
    
    if(maxLen == 0) {
        cout << "Khong tim thay tu nao!" << endl;
        return;
    }
    
    cout << "Tu dai nhat la: \"";
    for(int i = maxStart; i < maxStart + maxLen; i++) {
        cout << s[i];
    }
    cout << "\"" << endl;
    cout << "Do dai: " << maxLen << " ky tu" << endl;
    cout << "Vi tri bat dau: " << maxStart << endl;
}

int main() {
    char s[1000];
    
    cout << "Nhap chuoi: ";
    cin.getline(s, 1000);
    
    timTuDaiNhat(s);
    
    return 0;
}

