// BÀI 26: ĐẾM SỐ TỪ TRONG CHUỖI
#include <iostream>
#include <cstring>
using namespace std;

int demTu(char s[]) {
    int dem = 0;
    bool trongTu = false;
    
    for(int i = 0; i < strlen(s); i++) {
        if(s[i] != ' ' && s[i] != '\t' && s[i] != '\n') {
            if(!trongTu) {
                dem++;
                trongTu = true;
            }
        } else {
            trongTu = false;
        }
    }
    
    return dem;
}

int main() {
    char s[1000];
    
    cout << "Nhap chuoi: ";
    cin.getline(s, 1000);
    
    int soTu = demTu(s);
    
    cout << "Chuoi \"" << s << "\" co " << soTu << " tu." << endl;
    
    return 0;
}

