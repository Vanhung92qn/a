# BÀI TẬP LẬP TRÌNH C++ - LTCS

Đây là bộ giải đáp toàn bộ các bài tập trong file LTCS.pdf, được viết bằng C++ với code rõ ràng, dễ hiểu.

## 📁 CẤU TRÚC FILE

### PHẦN 1: CƠ BẢN - HÌNH HỌC
- `Bai01_02_HinhHoc.cpp` - Tính diện tích và chu vi hình chữ nhật, hình tròn

### PHẦN 2: LỆNH IF
- `Bai03_PhuongTrinhBac2.cpp` - Giải phương trình bậc 2
- `Bai04_SapXep5So.cpp` - Nhập 5 số và sắp xếp tăng dần
- `Bai05_LoaiTamGiac.cpp` - Xác định loại tam giác (vuông, cân, đều, thường)
- `Bai06_Max5So.cpp` - Tìm số lớn nhất của 5 số
- `Bai_PhuongTrinhBac1.cpp` - Giải phương trình bậc 1
- `Bai_SapXep3So.cpp` - Sắp xếp 3 số tăng dần
- `Bai_TinhTienDien.cpp` - Tính tiền điện theo hình thức lũy tiến

### PHẦN 3: VÒNG LẶP
- `Bai07_GCD_LCM.cpp` - Tìm ƯSCLN và BSCNN
- `Bai08_SoDoiXung.cpp` - Kiểm tra số đối xứng (palindrome)
- `Bai09_Fibonacci.cpp` - Tìm số Fibonacci thứ n
- `Bai10_SoArmstrong.cpp` - Tìm số Armstrong (153 = 1³ + 5³ + 3³)
- `Bai_SNTNhoHonN.cpp` - In các số nguyên tố nhỏ hơn n

### PHẦN 4: HÀM
- `Bai11_TongGiaiThua.cpp` - Tính tổng S(n) = 1 - 1/2! + 1/3! - ...
- `Bai12_NSoNguyenTo.cpp` - In ra n số nguyên tố đầu tiên

### PHẦN 5: MẢNG (BÀI 13-23)
- `Bai13_23_Mang.cpp` - Chương trình tổng hợp tất cả bài tập về mảng:
  - Nhập/xuất mảng
  - Tính tổng các số chẵn
  - Chèn phần tử vào mảng
  - Tìm số nguyên tố lớn nhất
  - Tìm 2 phần tử có tổng lớn nhất
  - Tính trung bình các số nguyên tố
  - Sắp xếp mảng tăng dần
  - Loại các giá trị âm
  - Loại các phần tử trùng nhau
  - Sắp xếp số hoàn thiện về đầu

### PHẦN 6: CHUỖI KÝ TỰ (BÀI 24-29)
- `Bai24_DemKyTu.cpp` - Đếm ký tự hoa, thường, số, đặc biệt
- `Bai25_ChuoiDoiXung.cpp` - Kiểm tra chuỗi đối xứng
- `Bai26_DemTu.cpp` - Đếm số từ trong chuỗi
- `Bai27_ChuanHoaChuoi.cpp` - Chuẩn hóa chuỗi (xóa khoảng trắng thừa, viết hoa đầu từ)
- `Bai28_TuDaiNhat.cpp` - Tìm từ dài nhất trong chuỗi
- `Bai29_NKyTuBenPhai.cpp` - Xuất n ký tự bên phải của chuỗi

### PHẦN 7: FILE (BÀI 30-32+)
- `Bai30_ToaDoSongSong.cpp` - Đọc tọa độ, ghi điểm song song trục hoành
- `Bai31_PhanSo.cpp` - Đọc file phân số và tìm phân số lớn nhất
- `Bai32_ThiSinh.cpp` - Đọc file thí sinh, sắp xếp và lọc thí sinh đậu
- `Bai_DocFileDiem.cpp` - Đọc file điểm và tính tổng, trung bình
- `Bai_DocFileSoNguyen.cpp` - Đọc file số nguyên và tính trung bình
- `Bai_DocFileInputTxt.cpp` - Đọc file input.txt và tính tổng số lẻ
- `Bai_TuyenSinh.cpp` - Đọc file tuyển sinh và lọc thí sinh đậu

### PHẦN 8: ĐỀ THI MẪU (QUAN TRỌNG!)
- `DeThi_Mau1.cpp` - Đề thi mẫu 1 (đầy đủ các câu)
- `DeThi_Mau2.cpp` - Đề thi mẫu 2 (đầy đủ các câu)
- `DeThi_Mau3.cpp` - Đề thi mẫu 3 (đầy đủ các câu)

### PHẦN 9: ĐỀ BÀI TẬP KẾT HỢP (MỚI - RẤT QUAN TRỌNG!)
- `De01_KetHop.cpp` - Năm nhuận, đảo số, mảng, sinh viên
- `De02_KetHop.cpp` - Ngày tiếp theo, tổng S, mảng, sách
- `De03_KetHop.cpp` - Máy tính điện tử, SNT, 2 mảng, xe máy
- `De04_KetHop.cpp` - Điểm trong tam giác, TB SNT, mảng, file số
