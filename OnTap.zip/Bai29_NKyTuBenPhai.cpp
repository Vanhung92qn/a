// BÀI 29: XUẤT N KÝ TỰ BÊN PHẢI CỦA CHUỖI
#include <iostream>
#include <cstring>
using namespace std;

void xuatNKyTuPhai(char s[], int n) {
    int len = strlen(s);
    
    if(n >= len) {
        cout << "Ket qua: " << s << endl;
        return;
    }
    
    cout << "Ket qua: ";
    for(int i = len - n; i < len; i++) {
        cout << s[i];
    }
    cout << endl;
}

int main() {
    char s[1000];
    int n;
    
    cout << "Nhap chuoi: ";
    cin.getline(s, 1000);
    
    cout << "Nhap so ky tu muon lay ben phai: ";
    cin >> n;
    
    if(n < 0) {
        cout << "So ky tu phai lon hon hoac bang 0!" << endl;
        return 0;
    }
    
    xuatNKyTuPhai(s, n);
    
    return 0;
}

