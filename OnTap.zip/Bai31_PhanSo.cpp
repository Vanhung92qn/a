// BÀI 31: ĐỌC FILE PHÂN SỐ VÀ TÌM PHÂN SỐ LỚN NHẤT
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
using namespace std;

struct PhanSo {
    int tu, mau;
    
    // Hàm tính giá trị thực của phân số
    double giaTriThuc() const {
        return (double)tu / mau;
    }
    
    // Hàm tối giản phân số
    void toiGian() {
        int a = abs(tu), b = abs(mau);
        while(b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        tu /= a;
        mau /= a;
        
        // Đảm bảo mẫu luôn dương
        if(mau < 0) {
            tu = -tu;
            mau = -mau;
        }
    }
};

int main() {
    ifstream fileIn("PhanSo.in");
    
    if(!fileIn) {
        cout << "Khong the mo file PhanSo.in!" << endl;
        return 1;
    }
    
    vector<PhanSo> danhSach;
    PhanSo ps;
    
    // Đọc các phân số
    while(fileIn >> ps.tu >> ps.mau) {
        if(ps.mau == 0) {
            cout << "Canh bao: Phan so co mau bang 0!" << endl;
            continue;
        }
        ps.toiGian();
        danhSach.push_back(ps);
    }
    
    fileIn.close();
    
    if(danhSach.empty()) {
        cout << "Khong co phan so nao trong file!" << endl;
        return 0;
    }
    
    // Hiển thị các phân số
    cout << "Cac phan so trong file:" << endl;
    for(int i = 0; i < danhSach.size(); i++) {
        cout << danhSach[i].tu << "/" << danhSach[i].mau << " = " 
             << fixed << setprecision(4) << danhSach[i].giaTriThuc() << endl;
    }
    
    // Tìm phân số lớn nhất
    int viTriMax = 0;
    for(int i = 1; i < danhSach.size(); i++) {
        if(danhSach[i].giaTriThuc() > danhSach[viTriMax].giaTriThuc()) {
            viTriMax = i;
        }
    }
    
    cout << fixed << setprecision(4);
    cout << "\nPhan so lon nhat la: " << danhSach[viTriMax].tu << "/" 
         << danhSach[viTriMax].mau << " = " << danhSach[viTriMax].giaTriThuc() << endl;
    
    return 0;
}

