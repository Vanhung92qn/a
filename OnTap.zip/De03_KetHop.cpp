// ĐỀ 3: BÀI TẬP KẾT HỢP
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <cmath>
using namespace std;

// ===== CÂU 1: MÁY TÍNH ĐIỆN TỬ =====
void cau1() {
    double a, b;
    char phepToan;
    
    cout << "Nhap so thu nhat: ";
    cin >> a;
    cout << "Nhap so thu hai: ";
    cin >> b;
    cout << "Nhap phep toan (+, -, *, /, ^): ";
    cin >> phepToan;
    
    double ketQua;
    bool hopLe = true;
    
    switch(phepToan) {
        case '+':
            ketQua = a + b;
            break;
        case '-':
            ketQua = a - b;
            break;
        case '*':
            ketQua = a * b;
            break;
        case '/':
            if(b == 0) {
                cout << "Loi: Khong the chia cho 0!" << endl;
                hopLe = false;
            } else {
                ketQua = a / b;
            }
            break;
        case '^':
            ketQua = pow(a, b);
            break;
        default:
            cout << "Phep toan khong hop le!" << endl;
            hopLe = false;
    }
    
    if(hopLe) {
        cout << fixed << setprecision(4);
        cout << "Ket qua: " << a << " " << phepToan << " " << b << " = " << ketQua << endl;
    }
}

// ===== CÂU 2: LIỆT KÊ N SỐ NGUYÊN TỐ ĐẦU TIÊN =====
bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

void cau2() {
    int n;
    do {
        cout << "Nhap n (n > 0): ";
        cin >> n;
    } while(n <= 0);
    
    cout << n << " so nguyen to dau tien: ";
    int dem = 0;
    int soHienTai = 2;
    
    while(dem < n) {
        if(laSNT(soHienTai)) {
            cout << soHienTai << " ";
            dem++;
        }
        soHienTai++;
    }
    cout << endl;
}

// ===== CÂU 3: 2 MẢNG =====
const int MAX = 1000;
int M1[MAX], M2[MAX], M3[MAX];
int n1, n2, n3;

void nhapMang(int a[], int &n, string ten) {
    cout << "Nhap so phan tu cua " << ten << ": ";
    cin >> n;
    for(int i = 0; i < n; i++) {
        cout << ten << "[" << i << "] = ";
        cin >> a[i];
    }
}

void xuatMang(int a[], int n, string ten) {
    cout << ten << ": ";
    for(int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

// a. M3 = M1 + M2
void congMang() {
    if(n1 != n2) {
        cout << "Hai mang phai co cung kich thuoc!" << endl;
        return;
    }
    
    n3 = n1;
    for(int i = 0; i < n3; i++) {
        M3[i] = M1[i] + M2[i];
    }
    
    cout << "Da tinh M3 = M1 + M2" << endl;
    xuatMang(M3, n3, "M3");
}

// b. Xuất M3 chẵn trước lẻ sau
void xuatChanTruocLeSau() {
    cout << "M3 (chan truoc, le sau): ";
    
    // In số chẵn trước
    for(int i = 0; i < n3; i++) {
        if(M3[i] % 2 == 0) {
            cout << M3[i] << " ";
        }
    }
    
    // In số lẻ sau
    for(int i = 0; i < n3; i++) {
        if(M3[i] % 2 != 0) {
            cout << M3[i] << " ";
        }
    }
    
    cout << endl;
}

// c. Sắp xếp M1, M2 tăng dần
void sapXepMang(int a[], int n) {
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) {
            if(a[i] > a[j]) {
                swap(a[i], a[j]);
            }
        }
    }
}

void sapXepCa2Mang() {
    sapXepMang(M1, n1);
    sapXepMang(M2, n2);
    cout << "Da sap xep M1 va M2 tang dan!" << endl;
    xuatMang(M1, n1, "M1");
    xuatMang(M2, n2, "M2");
}

// d. Trộn tăng M1 và M2 thành M3
void tronMangTang() {
    // Đảm bảo M1 và M2 đã sắp xếp
    sapXepMang(M1, n1);
    sapXepMang(M2, n2);
    
    int i = 0, j = 0, k = 0;
    
    while(i < n1 && j < n2) {
        if(M1[i] <= M2[j]) {
            M3[k++] = M1[i++];
        } else {
            M3[k++] = M2[j++];
        }
    }
    
    while(i < n1) {
        M3[k++] = M1[i++];
    }
    
    while(j < n2) {
        M3[k++] = M2[j++];
    }
    
    n3 = k;
    
    cout << "Da tron M1 va M2 thanh M3 tang dan!" << endl;
    xuatMang(M3, n3, "M3");
}

// ===== CÂU 4: XUẤT N KÝ TỰ BÊN PHẢI =====
void cau4() {
    cin.ignore();
    string s;
    int n;
    
    cout << "Nhap chuoi: ";
    getline(cin, s);
    cout << "Nhap so ky tu can lay: ";
    cin >> n;
    
    if(n < 0) {
        cout << "n phai >= 0!" << endl;
        return;
    }
    
    if(n >= s.length()) {
        cout << "Ket qua: " << s << endl;
    } else {
        cout << "Ket qua: " << s.substr(s.length() - n) << endl;
    }
}

// ===== CÂU 5: ĐỌC FILE XE MÁY =====
struct XeMay {
    string loaiXe;
    int namSX;
    int giaTien;
};

void cau5() {
    ifstream fileIn("Input_XeMay.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file Input_XeMay.txt!" << endl;
        return;
    }
    
    int soXe;
    fileIn >> soXe;
    
    vector<XeMay> dsXe;
    
    for(int i = 0; i < soXe; i++) {
        XeMay xe;
        fileIn >> xe.loaiXe >> xe.namSX >> xe.giaTien;
        dsXe.push_back(xe);
    }
    
    fileIn.close();
    
    // Hiển thị danh sách
    cout << "\n===== DANH SACH XE MAY =====" << endl;
    cout << "Loai xe\t\tNam SX\tGia (trieu)" << endl;
    cout << "----------------------------------------" << endl;
    
    for(int i = 0; i < dsXe.size(); i++) {
        cout << dsXe[i].loaiXe << "\t\t"
             << dsXe[i].namSX << "\t"
             << dsXe[i].giaTien << endl;
    }
    
    // Sắp xếp theo giá tiền tăng dần
    sort(dsXe.begin(), dsXe.end(), [](const XeMay &a, const XeMay &b) {
        return a.giaTien < b.giaTien;
    });
    
    cout << "\n===== DANH SACH SAU KHI SAP XEP =====" << endl;
    cout << "Loai xe\t\tNam SX\tGia (trieu)" << endl;
    cout << "----------------------------------------" << endl;
    
    for(int i = 0; i < dsXe.size(); i++) {
        cout << dsXe[i].loaiXe << "\t\t"
             << dsXe[i].namSX << "\t"
             << dsXe[i].giaTien << endl;
    }
    
    // Ghi vào file
    ofstream fileOut("Output_XeMay.txt");
    
    if(!fileOut) {
        cout << "Khong the tao file Output_XeMay.txt!" << endl;
        return;
    }
    
    for(int i = 0; i < dsXe.size(); i++) {
        fileOut << dsXe[i].loaiXe << " "
                << dsXe[i].namSX << " "
                << dsXe[i].giaTien << endl;
    }
    
    fileOut.close();
    
    cout << "\nDa ghi vao file Output_XeMay.txt" << endl;
}

// ===== MENU =====
void menu() {
    cout << "\n===== DE 3: BAI TAP KET HOP =====" << endl;
    cout << "1. Cau 1: May tinh dien tu" << endl;
    cout << "2. Cau 2: Liet ke n SNT dau tien" << endl;
    cout << "3. Cau 3: Nhap M1, M2" << endl;
    cout << "4. Cau 3: Xuat M1, M2" << endl;
    cout << "5. Cau 3a: Tinh M3 = M1 + M2" << endl;
    cout << "6. Cau 3b: Xuat M3 chan truoc le sau" << endl;
    cout << "7. Cau 3c: Sap xep M1, M2 tang dan" << endl;
    cout << "8. Cau 3d: Tron tang M1, M2 thanh M3" << endl;
    cout << "9. Cau 4: Xuat n ky tu ben phai" << endl;
    cout << "10. Cau 5: Doc file xe may" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1: cau1(); break;
            case 2: cau2(); break;
            case 3:
                nhapMang(M1, n1, "M1");
                nhapMang(M2, n2, "M2");
                break;
            case 4:
                xuatMang(M1, n1, "M1");
                xuatMang(M2, n2, "M2");
                break;
            case 5: congMang(); break;
            case 6: xuatChanTruocLeSau(); break;
            case 7: sapXepCa2Mang(); break;
            case 8: tronMangTang(); break;
            case 9: cau4(); break;
            case 10: cau5(); break;
            case 0: cout << "Tam biet!" << endl; break;
            default: cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

