// BÀI 13-23: CÁC BÀI TẬP VỀ MẢNG
#include <iostream>
#include <algorithm>
using namespace std;

const int MAX = 1000;

// Bài 13: Nhập mảng
void nhapMang(int a[], int &n) {
    do {
        cout << "Nhap so phan tu cua mang (n > 0): ";
        cin >> n;
    } while(n <= 0 || n > MAX);
    
    for(int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
}

// Bài 14: Xuất mảng
void xuatMang(int a[], int n) {
    cout << "Mang: ";
    for(int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

// Bài 15: Tính tổng các số chẵn
int tongSoChan(int a[], int n) {
    int tong = 0;
    for(int i = 0; i < n; i++) {
        if(a[i] % 2 == 0) {
            tong += a[i];
        }
    }
    return tong;
}

// Bài 16: Chèn giá trị x vào vị trí k
void chenPhanTu(int a[], int &n, int x, int k) {
    if(k < 0 || k > n) {
        cout << "Vi tri chen khong hop le!" << endl;
        return;
    }
    
    // Dịch các phần tử sang phải
    for(int i = n; i > k; i--) {
        a[i] = a[i-1];
    }
    
    a[k] = x;
    n++;
    
    cout << "Da chen " << x << " vao vi tri " << k << endl;
}

// Hàm kiểm tra số nguyên tố
bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

// Bài 17: Tìm số nguyên tố lớn nhất
int timSNTMax(int a[], int n) {
    int maxSNT = -1;
    for(int i = 0; i < n; i++) {
        if(laSNT(a[i])) {
            if(maxSNT == -1 || a[i] > maxSNT) {
                maxSNT = a[i];
            }
        }
    }
    return maxSNT;
}

// Bài 18: Tìm 2 phần tử có tổng lớn nhất
void tim2PhanTuTongMax(int a[], int n) {
    if(n < 2) {
        cout << "Mang phai co it nhat 2 phan tu!" << endl;
        return;
    }
    
    int max1 = a[0], max2 = a[1];
    if(max1 < max2) swap(max1, max2);
    
    for(int i = 2; i < n; i++) {
        if(a[i] > max1) {
            max2 = max1;
            max1 = a[i];
        } else if(a[i] > max2) {
            max2 = a[i];
        }
    }
    
    cout << "2 phan tu co tong lon nhat: " << max1 << " va " << max2 << endl;
    cout << "Tong cua chung: " << (max1 + max2) << endl;
}

// Bài 19: Tính trung bình các số nguyên tố
float trungBinhSNT(int a[], int n) {
    int tong = 0, dem = 0;
    for(int i = 0; i < n; i++) {
        if(laSNT(a[i])) {
            tong += a[i];
            dem++;
        }
    }
    
    if(dem == 0) return 0;
    return (float)tong / dem;
}

// Bài 20: Sắp xếp mảng tăng dần (Bubble Sort)
void sapXepTangDan(int a[], int n) {
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) {
            if(a[i] > a[j]) {
                swap(a[i], a[j]);
            }
        }
    }
}

// Bài 21: Loại tất cả các giá trị âm
void loaiGiaTriAm(int a[], int &n) {
    int j = 0;
    for(int i = 0; i < n; i++) {
        if(a[i] >= 0) {
            a[j++] = a[i];
        }
    }
    n = j;
}

// Bài 22: Loại các phần tử trùng nhau
void loaiPhanTuTrung(int a[], int &n) {
    int j = 0;
    for(int i = 0; i < n; i++) {
        bool trung = false;
        for(int k = 0; k < j; k++) {
            if(a[i] == a[k]) {
                trung = true;
                break;
            }
        }
        if(!trung) {
            a[j++] = a[i];
        }
    }
    n = j;
}

// Hàm kiểm tra số hoàn thiện
bool laSoHoanThien(int x) {
    if(x <= 0) return false;
    
    int tongUoc = 0;
    for(int i = 1; i <= x; i++) {
        if(x % i == 0) {
            tongUoc += i;
        }
    }
    
    return tongUoc == 2 * x;
}

// Bài 23: Đưa số hoàn thiện về đầu, không phải số hoàn thiện về cuối
void sapXepSoHoanThien(int a[], int n) {
    int left = 0, right = n - 1;
    
    while(left < right) {
        // Tìm số không phải hoàn thiện từ trái
        while(left < n && laSoHoanThien(a[left])) {
            left++;
        }
        
        // Tìm số hoàn thiện từ phải
        while(right >= 0 && !laSoHoanThien(a[right])) {
            right--;
        }
        
        // Hoán đổi
        if(left < right) {
            swap(a[left], a[right]);
            left++;
            right--;
        }
    }
}

// Menu chương trình
void menu() {
    cout << "\n===== MENU QUAN LY MANG =====" << endl;
    cout << "1. Nhap mang" << endl;
    cout << "2. Xuat mang" << endl;
    cout << "3. Tinh tong cac so chan" << endl;
    cout << "4. Chen phan tu vao mang" << endl;
    cout << "5. Tim so nguyen to lon nhat" << endl;
    cout << "6. Tim 2 phan tu co tong lon nhat" << endl;
    cout << "7. Tinh trung binh cac so nguyen to" << endl;
    cout << "8. Sap xep mang tang dan" << endl;
    cout << "9. Loai cac gia tri am" << endl;
    cout << "10. Loai cac phan tu trung" << endl;
    cout << "11. Sap xep so hoan thien ve dau" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int a[MAX], n = 0;
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1:
                nhapMang(a, n);
                break;
            case 2:
                if(n == 0) {
                    cout << "Mang rong!" << endl;
                } else {
                    xuatMang(a, n);
                }
                break;
            case 3:
                cout << "Tong cac so chan: " << tongSoChan(a, n) << endl;
                break;
            case 4: {
                int x, k;
                cout << "Nhap gia tri can chen: ";
                cin >> x;
                cout << "Nhap vi tri (0-" << n << "): ";
                cin >> k;
                chenPhanTu(a, n, x, k);
                break;
            }
            case 5: {
                int maxSNT = timSNTMax(a, n);
                if(maxSNT == -1) {
                    cout << "Khong co so nguyen to trong mang!" << endl;
                } else {
                    cout << "So nguyen to lon nhat: " << maxSNT << endl;
                }
                break;
            }
            case 6:
                tim2PhanTuTongMax(a, n);
                break;
            case 7: {
                float tb = trungBinhSNT(a, n);
                if(tb == 0) {
                    cout << "Khong co so nguyen to trong mang!" << endl;
                } else {
                    cout << "Trung binh cac so nguyen to: " << tb << endl;
                }
                break;
            }
            case 8:
                sapXepTangDan(a, n);
                cout << "Da sap xep mang tang dan!" << endl;
                xuatMang(a, n);
                break;
            case 9:
                loaiGiaTriAm(a, n);
                cout << "Da loai cac gia tri am!" << endl;
                xuatMang(a, n);
                break;
            case 10:
                loaiPhanTuTrung(a, n);
                cout << "Da loai cac phan tu trung!" << endl;
                xuatMang(a, n);
                break;
            case 11:
                sapXepSoHoanThien(a, n);
                cout << "Da sap xep so hoan thien ve dau!" << endl;
                xuatMang(a, n);
                break;
            case 0:
                cout << "Tam biet!" << endl;
                break;
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

