// GIẢI PHƯƠNG TRÌNH BẬC 1: Ax + B = 0
#include <iostream>
#include <iomanip>
using namespace std;

void giaiPTBac1() {
    float a, b;
    cout << "Giai phuong trinh bac 1: Ax + B = 0" << endl;
    cout << "Nhap he so a: ";
    cin >> a;
    cout << "Nhap he so b: ";
    cin >> b;
    
    if(a == 0) {
        if(b == 0) {
            cout << "Phuong trinh vo so nghiem!" << endl;
        } else {
            cout << "Phuong trinh vo nghiem!" << endl;
        }
    } else {
        cout << fixed << setprecision(2);
        cout << "Phuong trinh co nghiem duy nhat: x = " << -b/a << endl;
    }
}

int main() {
    giaiPTBac1();
    return 0;
}

