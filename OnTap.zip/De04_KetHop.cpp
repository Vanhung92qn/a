// ĐỀ 4: BÀI TẬP KẾT HỢP
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <cmath>
using namespace std;

// ===== CÂU 1: KIỂM TRA ĐIỂM D THUỘC TAM GIÁC ABC =====
struct Diem {
    double x, y;
};

// Tính diện tích tam giác từ 3 điểm
double dienTichTamGiac(Diem A, Diem B, Diem C) {
    return abs((B.x - A.x) * (C.y - A.y) - (C.x - A.x) * (B.y - A.y)) / 2.0;
}

bool diemTrongTamGiac(Diem A, Diem B, Diem C, Diem D) {
    double S_ABC = dienTichTamGiac(A, B, C);
    double S_DBC = dienTichTamGiac(D, B, C);
    double S_ADC = dienTichTamGiac(A, D, C);
    double S_ABD = dienTichTamGiac(A, B, D);
    
    const double epsilon = 1e-9;
    
    // D thuộc tam giác ABC nếu S_ABC = S_DBC + S_ADC + S_ABD
    return abs(S_ABC - (S_DBC + S_ADC + S_ABD)) < epsilon;
}

void cau1() {
    Diem A, B, C, D;
    
    cout << "Nhap toa do diem A (x y): ";
    cin >> A.x >> A.y;
    cout << "Nhap toa do diem B (x y): ";
    cin >> B.x >> B.y;
    cout << "Nhap toa do diem C (x y): ";
    cin >> C.x >> C.y;
    cout << "Nhap toa do diem D (x y): ";
    cin >> D.x >> D.y;
    
    if(diemTrongTamGiac(A, B, C, D)) {
        cout << "Diem D thuoc tam giac ABC!" << endl;
    } else {
        cout << "Diem D KHONG thuoc tam giac ABC!" << endl;
    }
}

// ===== CÂU 2: TRUNG BÌNH CÁC SỐ NGUYÊN TỐ =====
bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

void cau2() {
    int n;
    cout << "Nhap so luong so nguyen: ";
    cin >> n;
    
    int *a = new int[n];
    int tong = 0, dem = 0;
    
    cout << "Nhap " << n << " so nguyen:" << endl;
    for(int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
        
        if(laSNT(a[i])) {
            tong += a[i];
            dem++;
        }
    }
    
    if(dem == 0) {
        cout << "Khong co so nguyen to nao!" << endl;
    } else {
        cout << fixed << setprecision(2);
        cout << "Trung binh cac so nguyen to: " << (double)tong / dem << endl;
    }
    
    delete[] a;
}

// ===== CÂU 3: MẢNG =====
const int MAX = 1000;
int M[MAX], P[MAX];
int n, sizeP;

void nhapMang() {
    cout << "Nhap so phan tu: ";
    cin >> n;
    for(int i = 0; i < n; i++) {
        cout << "M[" << i << "] = ";
        cin >> M[i];
    }
}

void xuatMang() {
    cout << "Mang M: ";
    for(int i = 0; i < n; i++) {
        cout << M[i] << " ";
    }
    cout << endl;
}

// a. Loại các phần tử < 4
void loaiNhoHon4() {
    int j = 0;
    for(int i = 0; i < n; i++) {
        if(M[i] >= 4) {
            M[j++] = M[i];
        }
    }
    n = j;
    cout << "Da loai cac phan tu < 4!" << endl;
}

// b. Sắp xếp giảm dần
void sapXepGiamDan() {
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) {
            if(M[i] < M[j]) {
                swap(M[i], M[j]);
            }
        }
    }
    cout << "Da sap xep giam dan!" << endl;
}

// c. Tách mảng P chứa số nguyên tố
void tachMangSNT() {
    sizeP = 0;
    for(int i = 0; i < n; i++) {
        if(laSNT(M[i])) {
            P[sizeP++] = M[i];
        }
    }
    
    cout << "Mang P (chi chua SNT): ";
    for(int i = 0; i < sizeP; i++) {
        cout << P[i] << " ";
    }
    cout << endl;
}

// ===== CÂU 4: ĐẾM CÁC LOẠI KÝ TỰ =====
bool laNguyenAm(char c) {
    c = tolower(c);
    return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
}

bool laChuCai(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

bool laChuSo(char c) {
    return c >= '0' && c <= '9';
}

void cau4() {
    cin.ignore();
    string s;
    cout << "Nhap chuoi: ";
    getline(cin, s);
    
    int chuSo = 0, nguyenAm = 0, phuAm = 0, dacBiet = 0;
    
    for(int i = 0; i < s.length(); i++) {
        if(laChuSo(s[i])) {
            chuSo++;
        } else if(laChuCai(s[i])) {
            if(laNguyenAm(s[i])) {
                nguyenAm++;
            } else {
                phuAm++;
            }
        } else {
            dacBiet++;
        }
    }
    
    cout << "\n===== KET QUA =====" << endl;
    cout << "So chu so: " << chuSo << endl;
    cout << "So nguyen am: " << nguyenAm << endl;
    cout << "So phu am: " << phuAm << endl;
    cout << "So ky tu dac biet: " << dacBiet << endl;
}

// ===== CÂU 5: ĐỌC FILE SỐ NGUYÊN VÀ TÁCH SNT =====
void cau5() {
    ifstream fileIn("Input_SoNguyen.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file Input_SoNguyen.txt!" << endl;
        return;
    }
    
    int n;
    fileIn >> n;
    
    vector<int> danhSach;
    vector<int> cacSNT;
    
    for(int i = 0; i < n; i++) {
        int x;
        fileIn >> x;
        danhSach.push_back(x);
        
        if(laSNT(x)) {
            cacSNT.push_back(x);
        }
    }
    
    fileIn.close();
    
    // Hiển thị mảng
    cout << "\n===== MANG SO NGUYEN =====" << endl;
    for(int i = 0; i < danhSach.size(); i++) {
        cout << danhSach[i] << " ";
    }
    cout << endl;
    
    // Hiển thị các số nguyên tố
    cout << "\n===== CAC SO NGUYEN TO =====" << endl;
    for(int i = 0; i < cacSNT.size(); i++) {
        cout << cacSNT[i] << " ";
    }
    cout << endl;
    
    // Ghi vào file
    ofstream fileOut("Output_SoNguyen.txt");
    
    if(!fileOut) {
        cout << "Khong the tao file Output_SoNguyen.txt!" << endl;
        return;
    }
    
    for(int i = 0; i < cacSNT.size(); i++) {
        fileOut << cacSNT[i];
        if(i < cacSNT.size() - 1) {
            fileOut << " ";
        }
    }
    
    fileOut.close();
    
    cout << "\nDa ghi " << cacSNT.size() << " so nguyen to vao file Output_SoNguyen.txt" << endl;
}

// ===== MENU =====
void menu() {
    cout << "\n===== DE 4: BAI TAP KET HOP =====" << endl;
    cout << "1. Cau 1: Kiem tra diem D thuoc tam giac ABC" << endl;
    cout << "2. Cau 2: Trung binh cac so nguyen to" << endl;
    cout << "3. Cau 3: Nhap mang" << endl;
    cout << "4. Cau 3: Xuat mang" << endl;
    cout << "5. Cau 3a: Loai phan tu < 4" << endl;
    cout << "6. Cau 3b: Sap xep giam dan" << endl;
    cout << "7. Cau 3c: Tach mang P chua SNT" << endl;
    cout << "8. Cau 4: Dem cac loai ky tu" << endl;
    cout << "9. Cau 5: Doc file so nguyen va tach SNT" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1: cau1(); break;
            case 2: cau2(); break;
            case 3: nhapMang(); break;
            case 4: xuatMang(); break;
            case 5: loaiNhoHon4(); xuatMang(); break;
            case 6: sapXepGiamDan(); xuatMang(); break;
            case 7: tachMangSNT(); break;
            case 8: cau4(); break;
            case 9: cau5(); break;
            case 0: cout << "Tam biet!" << endl; break;
            default: cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

