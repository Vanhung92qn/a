// NHẬP 3 SỐ NGUYÊN VÀ IN RA THEO THỨ TỰ TĂNG DẦN
#include <iostream>
using namespace std;

int main() {
    int a, b, c;
    
    cout << "Nhap so thu nhat: ";
    cin >> a;
    cout << "Nhap so thu hai: ";
    cin >> b;
    cout << "Nhap so thu ba: ";
    cin >> c;
    
    // Sắp xếp bằng cách so sánh và hoán đổi
    if(a > b) swap(a, b);
    if(a > c) swap(a, c);
    if(b > c) swap(b, c);
    
    cout << "\nCac so theo thu tu tang dan: " << a << " " << b << " " << c << endl;
    
    return 0;
}

