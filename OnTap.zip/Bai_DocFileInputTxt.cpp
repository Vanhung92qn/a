// ĐỌC FILE input.txt VÀ TÍNH TỔNG CÁC SỐ LẺ
#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream fileIn("input.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file input.txt!" << endl;
        return 1;
    }
    
    int n;
    fileIn >> n;
    
    int *a = new int[n];
    int tongLe = 0;
    
    cout << "Cac phan tu trong file: ";
    for(int i = 0; i < n; i++) {
        fileIn >> a[i];
        cout << a[i] << " ";
        
        if(a[i] % 2 != 0) {
            tongLe += a[i];
        }
    }
    
    fileIn.close();
    
    cout << "\n\nTong cac so le: " << tongLe << endl;
    
    delete[] a;
    
    return 0;
}

