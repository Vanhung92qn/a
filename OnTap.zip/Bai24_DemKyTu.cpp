// BÀI 24: ĐẾM SỐ KÝ TỰ HOA, THƯỜNG, SỐ, ĐẶC BIỆT
#include <iostream>
#include <cstring>
using namespace std;

void demKyTu(char s[]) {
    int hoa = 0, thuong = 0, so = 0, dacBiet = 0;
    
    for(int i = 0; i < strlen(s); i++) {
        if(s[i] >= 'A' && s[i] <= 'Z') {
            hoa++;
        } else if(s[i] >= 'a' && s[i] <= 'z') {
            thuong++;
        } else if(s[i] >= '0' && s[i] <= '9') {
            so++;
        } else {
            dacBiet++;
        }
    }
    
    cout << "\n===== KET QUA =====" << endl;
    cout << "So ky tu hoa: " << hoa << endl;
    cout << "So ky tu thuong: " << thuong << endl;
    cout << "So ky tu so: " << so << endl;
    cout << "So ky tu dac biet: " << dacBiet << endl;
}

int main() {
    char s[1000];
    
    cout << "Nhap chuoi: ";
    cin.getline(s, 1000);
    
    cout << "Chuoi vua nhap: " << s << endl;
    demKyTu(s);
    
    return 0;
}

