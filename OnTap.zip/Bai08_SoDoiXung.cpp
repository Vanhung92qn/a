// BÀI 8: KIỂM TRA SỐ ĐỐI XỨNG (PALINDROME)
#include <iostream>
using namespace std;

bool laSoDoiXung(long long n) {
    long long goc = n;
    long long daoNguoc = 0;
    
    // Nếu n âm, không phải số đối xứng
    if (n < 0) return false;
    
    // Đảo ngược số
    while(n > 0) {
        daoNguoc = daoNguoc * 10 + n % 10;
        n /= 10;
    }
    
    return goc == daoNguoc;
}

int main() {
    long long n;
    
    cout << "Nhap mot so nguyen: ";
    cin >> n;
    
    if(laSoDoiXung(n)) {
        cout << n << " la so doi xung!" << endl;
    } else {
        cout << n << " khong phai la so doi xung!" << endl;
    }
    
    return 0;
}

