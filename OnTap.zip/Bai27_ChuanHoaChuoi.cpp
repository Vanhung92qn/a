// BÀI 27: CHUẨN HÓA CHUỖI (Xóa khoảng trắng thừa, viết hoa ký tự đầu mỗi từ)
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

void chuanHoaChuoi(char s[]) {
    // Bước 1: Xóa khoảng trắng đầu và cuối
    int start = 0;
    while(s[start] == ' ' || s[start] == '\t') start++;
    
    int end = strlen(s) - 1;
    while(end >= 0 && (s[end] == ' ' || s[end] == '\t')) end--;
    
    // Bước 2: Xóa khoảng trắng thừa giữa các từ và chuẩn hóa
    int j = 0;
    bool dauTu = true;
    
    for(int i = start; i <= end; i++) {
        if(s[i] != ' ' && s[i] != '\t') {
            // Ký tự đầu từ -> viết hoa, các ký tự khác -> viết thường
            if(dauTu) {
                s[j++] = toupper(s[i]);
                dauTu = false;
            } else {
                s[j++] = tolower(s[i]);
            }
        } else {
            // Chỉ thêm 1 khoảng trắng giữa các từ
            if(j > 0 && s[j-1] != ' ') {
                s[j++] = ' ';
            }
            dauTu = true;
        }
    }
    
    s[j] = '\0';
}

int main() {
    char s[1000];
    
    cout << "Nhap chuoi: ";
    cin.getline(s, 1000);
    
    cout << "Chuoi goc: \"" << s << "\"" << endl;
    
    chuanHoaChuoi(s);
    
    cout << "Chuoi sau khi chuan hoa: \"" << s << "\"" << endl;
    
    return 0;
}

