// BÀI 12: IN RA N SỐ NGUYÊN TỐ ĐẦU TIÊN
#include <iostream>
using namespace std;

// Hàm nhập n > 1
int nhap() {
    int n;
    do {
        cout << "Nhap so luong so nguyen to can in (n > 1): ";
        cin >> n;
        if(n <= 1) {
            cout << "Vui long nhap n > 1!" << endl;
        }
    } while(n <= 1);
    return n;
}

// Hàm kiểm tra số nguyên tố
bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

int main() {
    int n = nhap();
    
    cout << n << " so nguyen to dau tien la: " << endl;
    
    int dem = 0;
    int soHienTai = 2;
    
    while(dem < n) {
        if(laSNT(soHienTai)) {
            cout << soHienTai << " ";
            dem++;
            if(dem % 20 == 0) cout << endl; // Xuống dòng sau 20 số
        }
        soHienTai++;
    }
    
    cout << endl;
    
    return 0;
}

