// BÀI 7: TÌM ƯỚC SỐ CHUNG LỚN NHẤT (GCD) VÀ BỘI SỐ CHUNG NHỎ NHẤT (LCM)
#include <iostream>
#include <cmath>
using namespace std;

// Hàm tìm ƯSCLN (GCD) bằng thuật toán Euclid
int gcd(int a, int b) {
    a = abs(a);
    b = abs(b);
    
    while(b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Hàm tìm BSCNN (LCM)
int lcm(int a, int b) {
    return abs(a * b) / gcd(a, b);
}

int main() {
    int a, b;
    
    cout << "Nhap so nguyen a: ";
    cin >> a;
    cout << "Nhap so nguyen b: ";
    cin >> b;
    
    int ucln = gcd(a, b);
    int bcnn = lcm(a, b);
    
    cout << "\nUoc so chung lon nhat (GCD): " << ucln << endl;
    cout << "Boi so chung nho nhat (LCM): " << bcnn << endl;
    
    return 0;
}

