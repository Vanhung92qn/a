// BÀI 32: ĐỌC FILE THÍ SINH, SẮP XẾP VÀ LỌC THÍ SINH ĐẬU
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;

struct ThiSinh {
    string maTS;
    float mon1, mon2, mon3;
    float tongDiem;
    
    void tinhTongDiem() {
        tongDiem = mon1 + mon2 + mon3;
    }
    
    bool laDau() const {
        return tongDiem >= 12 && mon1 >= 1 && mon2 >= 1 && mon3 >= 1;
    }
};

// Hàm so sánh để sắp xếp theo tổng điểm giảm dần
bool soSanh(const ThiSinh &a, const ThiSinh &b) {
    return a.tongDiem > b.tongDiem;
}

int main() {
    ifstream fileIn("ThiSinh.txt");
    ofstream fileOut("ThiSinhDau.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file ThiSinh.txt!" << endl;
        return 1;
    }
    
    if(!fileOut) {
        cout << "Khong the tao file ThiSinhDau.txt!" << endl;
        return 1;
    }
    
    vector<ThiSinh> danhSach;
    ThiSinh ts;
    
    // Đọc thông tin thí sinh
    while(fileIn >> ts.maTS >> ts.mon1 >> ts.mon2 >> ts.mon3) {
        ts.tinhTongDiem();
        danhSach.push_back(ts);
    }
    
    fileIn.close();
    
    cout << "===== DANH SACH THI SINH =====" << endl;
    cout << fixed << setprecision(1);
    cout << "Ma TS\tMon1\tMon2\tMon3\tTong\tKet qua" << endl;
    cout << "------------------------------------------------" << endl;
    
    for(int i = 0; i < danhSach.size(); i++) {
        cout << danhSach[i].maTS << "\t"
             << danhSach[i].mon1 << "\t"
             << danhSach[i].mon2 << "\t"
             << danhSach[i].mon3 << "\t"
             << danhSach[i].tongDiem << "\t";
        
        if(danhSach[i].laDau()) {
            cout << "DAU" << endl;
        } else {
            cout << "TRUOT" << endl;
        }
    }
    
    // Sắp xếp theo tổng điểm giảm dần
    sort(danhSach.begin(), danhSach.end(), soSanh);
    
    cout << "\n===== DANH SACH SAU KHI SAP XEP =====" << endl;
    cout << "Ma TS\tMon1\tMon2\tMon3\tTong" << endl;
    cout << "----------------------------------------" << endl;
    
    for(int i = 0; i < danhSach.size(); i++) {
        cout << danhSach[i].maTS << "\t"
             << danhSach[i].mon1 << "\t"
             << danhSach[i].mon2 << "\t"
             << danhSach[i].mon3 << "\t"
             << danhSach[i].tongDiem << endl;
    }
    
    // Ghi thí sinh đậu vào file
    cout << "\n===== THI SINH DAU =====" << endl;
    cout << "Ma TS\tMon1\tMon2\tMon3\tTong" << endl;
    cout << "----------------------------------------" << endl;
    
    int demDau = 0;
    for(int i = 0; i < danhSach.size(); i++) {
        if(danhSach[i].laDau()) {
            fileOut << danhSach[i].maTS << " "
                    << danhSach[i].mon1 << " "
                    << danhSach[i].mon2 << " "
                    << danhSach[i].mon3 << endl;
            
            cout << danhSach[i].maTS << "\t"
                 << danhSach[i].mon1 << "\t"
                 << danhSach[i].mon2 << "\t"
                 << danhSach[i].mon3 << "\t"
                 << danhSach[i].tongDiem << endl;
            
            demDau++;
        }
    }
    
    fileOut.close();
    
    cout << "----------------------------------------" << endl;
    cout << "Tong so thi sinh: " << danhSach.size() << endl;
    cout << "So thi sinh dau: " << demDau << endl;
    cout << "Ty le dau: " << fixed << setprecision(2) 
         << (float)demDau / danhSach.size() * 100 << "%" << endl;
    cout << "\nDa ghi danh sach thi sinh dau vao file ThiSinhDau.txt" << endl;
    
    return 0;
}

