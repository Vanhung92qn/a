// BÀI 30: ĐỌC FILE TỌA ĐỘ VÀ GHI ĐIỂM SONG SONG TRỤC HOÀNH
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

struct Diem {
    int x, y;
};

int main() {
    ifstream fileIn("Diem.in");
    ofstream fileOut("Diem.out");
    
    if(!fileIn) {
        cout << "Khong the mo file Diem.in!" << endl;
        return 1;
    }
    
    if(!fileOut) {
        cout << "Khong the tao file Diem.out!" << endl;
        return 1;
    }
    
    vector<Diem> danhSach;
    Diem d;
    
    // Đọc tất cả các điểm
    while(fileIn >> d.x >> d.y) {
        danhSach.push_back(d);
    }
    
    fileIn.close();
    
    // Tìm tất cả giá trị y duy nhất (các đường song song trục hoành)
    vector<int> cacGiaTriY;
    for(int i = 0; i < danhSach.size(); i++) {
        bool daTonTai = false;
        for(int j = 0; j < cacGiaTriY.size(); j++) {
            if(danhSach[i].y == cacGiaTriY[j]) {
                daTonTai = true;
                break;
            }
        }
        if(!daTonTai) {
            cacGiaTriY.push_back(danhSach[i].y);
        }
    }
    
    // Với mỗi giá trị y, ghi các điểm có cùng y đó
    for(int i = 0; i < cacGiaTriY.size(); i++) {
        int y = cacGiaTriY[i];
        
        // Ghi các điểm có y = giá trị này
        for(int j = 0; j < danhSach.size(); j++) {
            if(danhSach[j].y == y) {
                fileOut << danhSach[j].x << "\t" << danhSach[j].y << endl;
            }
        }
        
        // Ghi dấu phân cách
        fileOut << "-------" << endl;
    }
    
    fileOut.close();
    
    cout << "Da ghi ket qua vao file Diem.out" << endl;
    cout << "Cac diem song song truc hoanh (cung tung do):" << endl;
    
    // Hiển thị kết quả ra màn hình
    for(int i = 0; i < cacGiaTriY.size(); i++) {
        int y = cacGiaTriY[i];
        cout << "\nNhom y = " << y << ":" << endl;
        
        for(int j = 0; j < danhSach.size(); j++) {
            if(danhSach[j].y == y) {
                cout << "(" << danhSach[j].x << ", " << danhSach[j].y << ") ";
            }
        }
        cout << endl;
    }
    
    return 0;
}

