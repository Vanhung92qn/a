// BÀI 25: KIỂM TRA CHUỖI ĐỐI XỨNG
#include <iostream>
#include <cstring>
using namespace std;

bool laChuoiDoiXung(char s[]) {
    int n = strlen(s);
    
    for(int i = 0; i < n/2; i++) {
        if(s[i] != s[n-1-i]) {
            return false;
        }
    }
    
    return true;
}

int main() {
    char s[1000];
    
    cout << "Nhap chuoi: ";
    cin.getline(s, 1000);
    
    if(laChuoiDoiXung(s)) {
        cout << "\"" << s << "\" la chuoi doi xung!" << endl;
    } else {
        cout << "\"" << s << "\" khong phai la chuoi doi xung!" << endl;
    }
    
    return 0;
}

