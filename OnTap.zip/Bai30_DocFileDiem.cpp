// BÀI 30: ĐỌC FILE ĐIỂM VÀ TÍNH TỔNG, TRUNG BÌNH
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

int main() {
    ifstream fileIn("Diem.in");
    
    if(!fileIn) {
        cout << "Khong the mo file Diem.in!" << endl;
        return 1;
    }
    
    int n;
    fileIn >> n;
    
    float *diem = new float[n];
    float tong = 0;
    
    cout << "Cac diem trong file:" << endl;
    for(int i = 0; i < n; i++) {
        fileIn >> diem[i];
        cout << diem[i] << " ";
        tong += diem[i];
    }
    
    fileIn.close();
    
    float trungBinh = tong / n;
    
    cout << fixed << setprecision(2);
    cout << "\n\nTong diem: " << tong << endl;
    cout << "Trung binh: " << trungBinh << endl;
    
    delete[] diem;
    
    return 0;
}

