// BÀI 3: GIẢI PHƯƠNG TRÌNH BẬC 2: Ax² + Bx + C = 0
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

void giaiPTBac2() {
    float a, b, c;
    cout << "Giai phuong trinh bac 2: Ax^2 + Bx + C = 0" << endl;
    cout << "Nhap he so a: ";
    cin >> a;
    cout << "Nhap he so b: ";
    cin >> b;
    cout << "Nhap he so c: ";
    cin >> c;
    
    // Kiểm tra a = 0 (phương trình bậc 1)
    if (a == 0) {
        if (b == 0) {
            if (c == 0) {
                cout << "Phuong trinh vo so nghiem!" << endl;
            } else {
                cout << "Phuong trinh vo nghiem!" << endl;
            }
        } else {
            cout << "Phuong trinh co nghiem duy nhat: x = " << fixed << setprecision(2) << -c/b << endl;
        }
        return;
    }
    
    // Tính delta
    float delta = b*b - 4*a*c;
    
    cout << fixed << setprecision(2);
    
    if (delta < 0) {
        cout << "Phuong trinh vo nghiem!" << endl;
    } else if (delta == 0) {
        float x = -b / (2*a);
        cout << "Phuong trinh co nghiem kep: x = " << x << endl;
    } else {
        float x1 = (-b + sqrt(delta)) / (2*a);
        float x2 = (-b - sqrt(delta)) / (2*a);
        cout << "Phuong trinh co 2 nghiem phan biet:" << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    }
}

int main() {
    giaiPTBac2();
    return 0;
}

