// BÀI 4: NHẬP 5 SỐ NGUYÊN VÀ IN RA THEO THỨ TỰ TĂNG DẦN
#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int a[5];
    
    cout << "Nhap 5 so nguyen:" << endl;
    for(int i = 0; i < 5; i++) {
        cout << "So thu " << (i+1) << ": ";
        cin >> a[i];
    }
    
    // Sắp xếp tăng dần (Bubble Sort)
    for(int i = 0; i < 4; i++) {
        for(int j = i+1; j < 5; j++) {
            if(a[i] > a[j]) {
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
    
    // Hoặc có thể dùng hàm sort của C++:
    // sort(a, a+5);
    
    cout << "\nCac so theo thu tu tang dan: ";
    for(int i = 0; i < 5; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
    
    return 0;
}

