// BÀI 11: TÍNH TỔNG S(n) = 1 - 1/2! + 1/3! - 1/4! + ... + (-1)^(n+1) * 1/n!
#include <iostream>
#include <iomanip>
using namespace std;

// Hàm nhập n nguyên dương
int nhap() {
    int n;
    do {
        cout << "Nhap n nguyen duong: ";
        cin >> n;
        if(n <= 0) {
            cout << "Vui long nhap n > 0!" << endl;
        }
    } while(n <= 0);
    return n;
}

// Hàm tính giai thừa
long long giaiThua(int x) {
    long long ketQua = 1;
    for(int i = 1; i <= x; i++) {
        ketQua *= i;
    }
    return ketQua;
}

// Hàm tính tổng
double tinhTong(int n) {
    double tong = 0;
    for(int i = 1; i <= n; i++) {
        // Dấu của mỗi số hạng: (-1)^(i+1)
        int dau = (i % 2 == 1) ? 1 : -1;
        tong += dau * (1.0 / giaiThua(i));
    }
    return tong;
}

int main() {
    int n = nhap();
    double ketQua = tinhTong(n);
    
    cout << fixed << setprecision(10);
    cout << "S(" << n << ") = " << ketQua << endl;
    
    // In chi tiết công thức
    cout << "\nCong thuc: S(" << n << ") = ";
    for(int i = 1; i <= n; i++) {
        int dau = (i % 2 == 1) ? 1 : -1;
        if(i > 1) {
            cout << (dau > 0 ? " + " : " - ");
        }
        cout << "1/" << i << "!";
    }
    cout << endl;
    
    return 0;
}

