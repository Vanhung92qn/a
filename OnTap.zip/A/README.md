### Câu 1: Tính tổng các ước số 
**File:** `cau1.cpp`

**Yêu cầu:**
- Nhập số nguyên dương n (nhập lại nếu n ≤ 0)
- Tính tổng tất cả các ước số của n

**Ví dụ:**
```
Nhập n = 12
Các ước: 1, 2, 3, 4, 6, 12
Tổng = 28
```

---

### Câu 2: Cộng hai phân số 
**File:** `cau2.cpp`

**Yêu cầu:**
- Sử dụng struct để lưu phân số (tử, mẫu)
- Nhập 2 phân số
- Cộng hai phân số và hiển thị kết quả (tối giản)

**Ví dụ:**
```
Phân số 1: 1/2
Phân số 2: 1/3
Kết quả: 1/2 + 1/3 = 5/6
```

---

### Câu 3: Xử lý mảng 
**File:** `cau3.cpp`

**Yêu cầu:**
1. Hàm nhập mảng số nguyên n phần tử
2. Hàm xuất mảng
3. Kiểm tra số x có tồn tại trong mảng (in vị trí hoặc thông báo)
4. Tách mảng thành 2 mảng:
   - Mảng 1: Các phần tử chia hết cho x
   - Mảng 2: Các phần tử còn lại

**Ví dụ:**
```
Mảng: [10, 15, 20, 25, 30]
x = 5
→ Mảng chia hết cho 5: [10, 15, 20, 25, 30]
→ Mảng còn lại: []
```

---

### Câu 4: File operations 
**File:** `cau4.cpp`

**Yêu cầu:**

**a) Tạo file output.txt** với nội dung:
```
8
20 24 19 98
```
- Dòng 1: Số phần tử
- Dòng 2: Các phần tử

**b) Đọc file và tìm max:**
- Đọc và hiển thị nội dung file
- Tìm và in ra phần tử lớn nhất

**Kết quả:**
```
Phần tử lớn nhất: 98
```