// CÂU 1: TÍNH TỔNG CÁC ƯỚC SỐ CỦA N
#include <iostream>
using namespace std;

int main() {
    int n;
    
    // Nhập n, yêu cầu nhập lại nếu n <= 0
    do {
        cout << "Nhap so nguyen duong n: ";
        cin >> n;
        
        if(n <= 0) {
            cout << "Vui long nhap n > 0!" << endl;
        }
    } while(n <= 0);
    
    // Tính tổng các ước số của n
    int tongUoc = 0;
    
    cout << "Cac uoc so cua " << n << " la: ";
    for(int i = 1; i <= n; i++) {
        if(n % i == 0) {
            cout << i << " ";
            tongUoc += i;
        }
    }
    
    cout << "\n\nTong cac uoc so cua " << n << " la: " << tongUoc << endl;
    
    return 0;
}

