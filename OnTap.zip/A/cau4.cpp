// CÂU 4: TẠO VÀ ĐỌC FILE, TÌM PHẦN TỬ LỚN NHẤT
#include <iostream>
#include <fstream>
using namespace std;

// Câu 4a: Tạo file output.txt với dữ liệu cho trước
void taoFile() {
    ofstream fileOut("output.txt");
    
    if(!fileOut) {
        cout << "Khong the tao file output.txt!" << endl;
        return;
    }
    
    // Ghi dòng 1: số phần tử
    fileOut << "8" << endl;
    
    // Ghi dòng 2: các phần tử
    fileOut << "20 24 19 98" << endl;
    
    fileOut.close();
    
    cout << "Da tao file output.txt thanh cong!" << endl;
    cout << "Noi dung file:" << endl;
    cout << "Dong 1: 8 (so phan tu)" << endl;
    cout << "Dong 2: 20 24 19 98 (cac phan tu)" << endl;
}

// Câu 4b: Đọc file và tìm phần tử lớn nhất
void docFileVaTimMax() {
    ifstream fileIn("output.txt");
    
    if(!fileIn) {
        cout << "\nKhong the mo file output.txt!" << endl;
        cout << "Vui long chay chuc nang 'Tao file' truoc!" << endl;
        return;
    }
    
    int soPhanTu;
    fileIn >> soPhanTu;
    
    cout << "\n===== NOI DUNG FILE output.txt =====" << endl;
    cout << "So phan tu: " << soPhanTu << endl;
    
    // Đọc các phần tử
    int *mang = new int[soPhanTu];
    int dem = 0;
    
    cout << "Cac phan tu: ";
    while(dem < soPhanTu && fileIn >> mang[dem]) {
        cout << mang[dem] << " ";
        dem++;
    }
    cout << endl;
    
    fileIn.close();
    
    if(dem == 0) {
        cout << "\nKhong co phan tu nao trong file!" << endl;
        delete[] mang;
        return;
    }
    
    // Tìm phần tử lớn nhất
    int max = mang[0];
    for(int i = 1; i < dem; i++) {
        if(mang[i] > max) {
            max = mang[i];
        }
    }
    
    cout << "\nPhan tu lon nhat la: " << max << endl;
    
    delete[] mang;
}

// Menu
void menu() {
    cout << "\n===== MENU =====" << endl;
    cout << "1. Tao file output.txt" << endl;
    cout << "2. Doc file va tim phan tu lon nhat" << endl;
    cout << "3. Thuc hien ca 2 chuc nang" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1:
                taoFile();
                break;
                
            case 2:
                docFileVaTimMax();
                break;
                
            case 3:
                taoFile();
                docFileVaTimMax();
                break;
                
            case 0:
                cout << "Tam biet!" << endl;
                break;
                
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

