// CÂU 2: CỘNG HAI PHÂN SỐ (SỬ DỤNG STRUCT)
#include <iostream>
using namespace std;

// Struct phân số
struct PhanSo {
    int tu;
    int mau;
};

// Hàm tìm ƯSCLN (GCD)
int gcd(int a, int b) {
    a = abs(a);
    b = abs(b);
    while(b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Hàm nhập phân số
void nhapPhanSo(PhanSo &ps) {
    cout << "Nhap tu so: ";
    cin >> ps.tu;
    
    do {
        cout << "Nhap mau so (khac 0): ";
        cin >> ps.mau;
        
        if(ps.mau == 0) {
            cout << "Mau so phai khac 0! Vui long nhap lai." << endl;
        }
    } while(ps.mau == 0);
}

// Hàm xuất phân số
void xuatPhanSo(const PhanSo &ps) {
    if(ps.mau == 1) {
        cout << ps.tu;
    } else if(ps.mau < 0) {
        cout << -ps.tu << "/" << -ps.mau;
    } else {
        cout << ps.tu << "/" << ps.mau;
    }
}

// Hàm tối giản phân số
void toiGian(PhanSo &ps) {
    int ucln = gcd(ps.tu, ps.mau);
    ps.tu /= ucln;
    ps.mau /= ucln;
    
    // Đưa dấu âm về tử số
    if(ps.mau < 0) {
        ps.tu = -ps.tu;
        ps.mau = -ps.mau;
    }
}

// Hàm cộng hai phân số
PhanSo congPhanSo(const PhanSo &ps1, const PhanSo &ps2) {
    PhanSo ketQua;
    
    // a/b + c/d = (a*d + b*c) / (b*d)
    ketQua.tu = ps1.tu * ps2.mau + ps2.tu * ps1.mau;
    ketQua.mau = ps1.mau * ps2.mau;
    
    // Tối giản kết quả
    toiGian(ketQua);
    
    return ketQua;
}

int main() {
    PhanSo ps1, ps2, tong;
    
    cout << "===== CONG HAI PHAN SO =====" << endl;
    
    // Nhập phân số thứ nhất
    cout << "\nNhap phan so thu nhat:" << endl;
    nhapPhanSo(ps1);
    
    // Nhập phân số thứ hai
    cout << "\nNhap phan so thu hai:" << endl;
    nhapPhanSo(ps2);
    
    // Cộng hai phân số
    tong = congPhanSo(ps1, ps2);
    
    // Hiển thị kết quả
    cout << "\n===== KET QUA =====" << endl;
    xuatPhanSo(ps1);
    cout << " + ";
    xuatPhanSo(ps2);
    cout << " = ";
    xuatPhanSo(tong);
    cout << endl;
    
    return 0;
}

