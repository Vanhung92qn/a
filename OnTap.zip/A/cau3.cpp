// CÂU 3: MẢNG - NHẬP, XUẤT, TÌM KIẾM, TÁCH MẢNG
#include <iostream>
using namespace std;

const int MAX = 1000;

// Hàm nhập mảng
void nhapMang(int a[], int &n) {
    do {
        cout << "Nhap so phan tu cua mang (n > 0): ";
        cin >> n;
        
        if(n <= 0 || n > MAX) {
            cout << "Vui long nhap 0 < n <= " << MAX << endl;
        }
    } while(n <= 0 || n > MAX);
    
    cout << "Nhap cac phan tu cua mang:" << endl;
    for(int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
}

// Hàm xuất mảng
void xuatMang(int a[], int n, string tenMang = "Mang") {
    cout << tenMang << ": ";
    for(int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

// Hàm kiểm tra x có tồn tại trong mảng hay không
void kiemTraTonTai(int a[], int n) {
    int x;
    cout << "\nNhap so nguyen x can tim: ";
    cin >> x;
    
    bool timThay = false;
    cout << "Ket qua tim kiem:" << endl;
    
    for(int i = 0; i < n; i++) {
        if(a[i] == x) {
            cout << "Tim thay " << x << " tai vi tri " << i << endl;
            timThay = true;
        }
    }
    
    if(!timThay) {
        cout << "Khong tim thay " << x << " trong mang!" << endl;
    }
}

// Hàm tách mảng theo x
void tachMang(int a[], int n) {
    int x;
    cout << "\nNhap so nguyen x de tach mang: ";
    cin >> x;
    
    if(x == 0) {
        cout << "Khong the chia cho 0!" << endl;
        return;
    }
    
    int mangChiaHet[MAX], nChiaHet = 0;
    int mangConLai[MAX], nConLai = 0;
    
    // Phân loại các phần tử
    for(int i = 0; i < n; i++) {
        if(a[i] % x == 0) {
            mangChiaHet[nChiaHet++] = a[i];
        } else {
            mangConLai[nConLai++] = a[i];
        }
    }
    
    // Hiển thị kết quả
    cout << "\n===== KET QUA TACH MANG =====" << endl;
    cout << "Gia tri x = " << x << endl;
    
    cout << "\nMang cac phan tu chia het cho " << x << " (co " << nChiaHet << " phan tu):" << endl;
    if(nChiaHet > 0) {
        xuatMang(mangChiaHet, nChiaHet, "");
    } else {
        cout << "(Khong co phan tu nao)" << endl;
    }
    
    cout << "\nMang cac phan tu khong chia het cho " << x << " (co " << nConLai << " phan tu):" << endl;
    if(nConLai > 0) {
        xuatMang(mangConLai, nConLai, "");
    } else {
        cout << "(Khong co phan tu nao)" << endl;
    }
}

// Menu
void menu() {
    cout << "\n===== MENU =====" << endl;
    cout << "1. Nhap mang" << endl;
    cout << "2. Xuat mang" << endl;
    cout << "3. Kiem tra x co ton tai trong mang" << endl;
    cout << "4. Tach mang theo chia het cho x" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int a[MAX], n = 0;
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1:
                nhapMang(a, n);
                break;
                
            case 2:
                if(n == 0) {
                    cout << "Mang rong! Vui long nhap mang truoc." << endl;
                } else {
                    cout << "\n";
                    xuatMang(a, n, "Mang hien tai");
                }
                break;
                
            case 3:
                if(n == 0) {
                    cout << "Mang rong! Vui long nhap mang truoc." << endl;
                } else {
                    kiemTraTonTai(a, n);
                }
                break;
                
            case 4:
                if(n == 0) {
                    cout << "Mang rong! Vui long nhap mang truoc." << endl;
                } else {
                    tachMang(a, n);
                }
                break;
                
            case 0:
                cout << "Tam biet!" << endl;
                break;
                
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

