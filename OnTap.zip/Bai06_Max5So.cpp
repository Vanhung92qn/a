// BÀI 6: TÌM SỐ LỚN NHẤT CỦA 5 SỐ
#include <iostream>
using namespace std;

int main() {
    int a[5];
    
    cout << "Nhap 5 so nguyen:" << endl;
    for(int i = 0; i < 5; i++) {
        cout << "So thu " << (i+1) << ": ";
        cin >> a[i];
    }
    
    int max = a[0];
    for(int i = 1; i < 5; i++) {
        if(a[i] > max) {
            max = a[i];
        }
    }
    
    cout << "\nSo lon nhat la: " << max << endl;
    
    return 0;
}

