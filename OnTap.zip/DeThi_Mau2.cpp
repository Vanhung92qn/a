// ĐỀ THI MẪU 2
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

// ===== CÂU 1: TÌM CHỮ SỐ CHẴN LỚN NHẤT =====
void timChuSoChanMax() {
    long long n;
    cout << "Nhap so nguyen: ";
    cin >> n;
    
    if(n < 0) n = -n; // Xử lý số âm
    
    int maxChan = -1;
    
    while(n > 0) {
        int chuSo = n % 10;
        if(chuSo % 2 == 0) { // Chữ số chẵn
            if(maxChan == -1 || chuSo > maxChan) {
                maxChan = chuSo;
            }
        }
        n /= 10;
    }
    
    if(maxChan == -1) {
        cout << "Khong tim thay chu so chan!" << endl;
    } else {
        cout << "Chu so chan lon nhat la: " << maxChan << endl;
    }
}

// ===== CÂU 2: TÌM CÁC ƯỚC CỦA N =====
void timUoc() {
    int n;
    cout << "Nhap so nguyen duong n: ";
    cin >> n;
    
    if(n <= 0) {
        cout << "Vui long nhap so nguyen duong!" << endl;
        return;
    }
    
    cout << "Cac uoc cua " << n << " la: ";
    for(int i = 1; i <= n; i++) {
        if(n % i == 0) {
            cout << i << " ";
        }
    }
    cout << endl;
}

// ===== CÂU 3: MẢNG =====
void nhapMang(int a[], int &n) {
    do {
        cout << "Nhap so phan tu: ";
        cin >> n;
    } while(n <= 0 || n > 1000);
    
    for(int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
}

void xuatMang(int a[], int n) {
    cout << "Mang: ";
    for(int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

int tongSNT(int a[], int n) {
    int tong = 0;
    for(int i = 0; i < n; i++) {
        if(laSNT(a[i])) {
            tong += a[i];
        }
    }
    return tong;
}

void tachSNT(int a[], int n, int snt[], int &sizeSNT) {
    sizeSNT = 0;
    for(int i = 0; i < n; i++) {
        if(laSNT(a[i])) {
            snt[sizeSNT++] = a[i];
        }
    }
}

// ===== CÂU 4: ĐẾM SỐ TỪ =====
int demSoTu(char s[]) {
    int dem = 0;
    bool trongTu = false;
    
    for(int i = 0; i < strlen(s); i++) {
        if(s[i] != ' ' && s[i] != '\t' && s[i] != '\n') {
            if(!trongTu) {
                dem++;
                trongTu = true;
            }
        } else {
            trongTu = false;
        }
    }
    
    return dem;
}

// ===== CÂU 5: ĐỌC FILE VÀ TÍNH TỔNG SỐ LẺ =====
void docFileTinhTongLe() {
    ifstream fileIn("input.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file input.txt!" << endl;
        return;
    }
    
    int n;
    fileIn >> n;
    
    int *a = new int[n];
    int tongLe = 0;
    
    for(int i = 0; i < n; i++) {
        fileIn >> a[i];
        if(a[i] % 2 != 0) {
            tongLe += a[i];
        }
    }
    
    fileIn.close();
    
    cout << "Tong cac so le: " << tongLe << endl;
    
    delete[] a;
}

// ===== MENU =====
void menu() {
    cout << "\n===== DE THI MAU 2 =====" << endl;
    cout << "1. Cau 1: Tim chu so chan lon nhat" << endl;
    cout << "2. Cau 2: Tim cac uoc cua n" << endl;
    cout << "3. Cau 3a: Nhap/Xuat mang" << endl;
    cout << "4. Cau 3b: Tinh tong SNT" << endl;
    cout << "5. Cau 3c: Tach SNT" << endl;
    cout << "6. Cau 4: Dem so tu" << endl;
    cout << "7. Cau 5: Doc file tinh tong le" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int a[1000], n = 0;
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        cin.ignore();
        
        switch(luaChon) {
            case 1:
                timChuSoChanMax();
                break;
            case 2:
                timUoc();
                break;
            case 3:
                nhapMang(a, n);
                xuatMang(a, n);
                break;
            case 4:
                cout << "Tong cac SNT: " << tongSNT(a, n) << endl;
                break;
            case 5: {
                int snt[1000], sizeSNT;
                tachSNT(a, n, snt, sizeSNT);
                cout << "Cac SNT trong mang: ";
                for(int i = 0; i < sizeSNT; i++) {
                    cout << snt[i] << " ";
                }
                cout << endl;
                break;
            }
            case 6: {
                char s[1000];
                cout << "Nhap ho ten: ";
                cin.getline(s, 1000);
                cout << "Ho ten: " << s << endl;
                cout << "So tu: " << demSoTu(s) << endl;
                break;
            }
            case 7:
                docFileTinhTongLe();
                break;
            case 0:
                cout << "Tam biet!" << endl;
                break;
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

