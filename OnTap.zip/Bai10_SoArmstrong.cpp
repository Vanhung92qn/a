// BÀI 10: TÌM SỐ ARMSTRONG (SỐ CÓ 3 CHỮ SỐ = TỔNG LẬP PHƯƠNG CÁC CHỮ SỐ)
// Ví dụ: 153 = 1³ + 5³ + 3³
#include <iostream>
#include <cmath>
using namespace std;

bool laSoArmstrong(int n) {
    int goc = n;
    int tong = 0;
    
    while(n > 0) {
        int chuSo = n % 10;
        tong += chuSo * chuSo * chuSo; // Lập phương
        n /= 10;
    }
    
    return goc == tong;
}

int main() {
    cout << "Cac so Armstrong co 3 chu so:" << endl;
    
    int dem = 0;
    for(int i = 100; i <= 999; i++) {
        if(laSoArmstrong(i)) {
            cout << i << " ";
            dem++;
            if(dem % 10 == 0) cout << endl; // Xuống dòng sau 10 số
        }
    }
    
    cout << "\n\nTong cong co " << dem << " so Armstrong co 3 chu so." << endl;
    
    return 0;
}

