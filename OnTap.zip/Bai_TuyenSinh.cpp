// ĐỌC FILE TUYỂN SINH VÀ LỌC THÍ SINH ĐẬU
// Điều kiện đậu: Tổng điểm >= 15 và không môn nào < 1
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

struct ThiSinh {
    char maTS[10];
    float mon1, mon2, mon3;
    float tongDiem;
};

bool kiemTraDau(ThiSinh ts) {
    // Kiểm tra không môn nào liệt (< 1)
    if(ts.mon1 < 1 || ts.mon2 < 1 || ts.mon3 < 1) {
        return false;
    }
    
    // Kiểm tra tổng điểm >= 15
    ts.tongDiem = ts.mon1 + ts.mon2 + ts.mon3;
    if(ts.tongDiem < 15) {
        return false;
    }
    
    return true;
}

int main() {
    ifstream fileIn("nguon.txt");
    ofstream fileOut("dich.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file nguon.txt!" << endl;
        return 1;
    }
    
    if(!fileOut) {
        cout << "Khong the tao file dich.txt!" << endl;
        return 1;
    }
    
    ThiSinh ts;
    int tongTS = 0, tsDau = 0;
    
    cout << fixed << setprecision(2);
    cout << "===== DANH SACH THI SINH DAU =====" << endl;
    cout << "Ma TS\tMon 1\tMon 2\tMon 3\tTong" << endl;
    cout << "----------------------------------------" << endl;
    
    while(fileIn >> ts.maTS >> ts.mon1 >> ts.mon2 >> ts.mon3) {
        tongTS++;
        ts.tongDiem = ts.mon1 + ts.mon2 + ts.mon3;
        
        if(kiemTraDau(ts)) {
            // In ra màn hình
            cout << ts.maTS << "\t" << ts.mon1 << "\t" << ts.mon2 << "\t" 
                 << ts.mon3 << "\t" << ts.tongDiem << endl;
            
            // Ghi vào file
            fileOut << ts.maTS << " " << ts.mon1 << " " << ts.mon2 << " " 
                    << ts.mon3 << endl;
            
            tsDau++;
        }
    }
    
    fileIn.close();
    fileOut.close();
    
    cout << "----------------------------------------" << endl;
    cout << "Tong so thi sinh: " << tongTS << endl;
    cout << "So thi sinh dau: " << tsDau << endl;
    cout << "Ty le dau: " << (tongTS > 0 ? (float)tsDau/tongTS*100 : 0) << "%" << endl;
    cout << "\nDa luu ket qua vao file dich.txt" << endl;
    
    return 0;
}

