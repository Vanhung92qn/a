// CÂU 5: STRUCT SINH VIÊN VỚI STRUCT CON ĐIỂM
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <string>
using namespace std;

// Struct con Diem
struct Diem {
    float toan, ly, hoa;
    
    // Hàm tính điểm trung bình
    float diemTB() const {
        return (toan + ly + hoa) / 3.0;
    }
};

// Struct Sinh viên
struct SinhVien {
    string mssv;
    string hoTen;
    Diem diem;  // Struct con
    
    // Hàm tính điểm TB (gọi từ struct con)
    float diemTrungBinh() const {
        return diem.diemTB();
    }
};

// ===== CÂU 5a: CÁC HÀM NHẬP/XUẤT =====

// Hàm nhập thông tin 1 sinh viên
void nhapSinhVien(SinhVien &sv) {
    cout << "\nNhap MSSV: ";
    cin.ignore();
    getline(cin, sv.mssv);
    
    cout << "Nhap ho ten: ";
    getline(cin, sv.hoTen);
    
    cout << "Nhap diem Toan: ";
    cin >> sv.diem.toan;
    
    cout << "Nhap diem Ly: ";
    cin >> sv.diem.ly;
    
    cout << "Nhap diem Hoa: ";
    cin >> sv.diem.hoa;
}

// Hàm nhập danh sách sinh viên
void nhapDanhSach(vector<SinhVien> &ds) {
    int n;
    cout << "Nhap so luong sinh vien: ";
    cin >> n;
    
    for(int i = 0; i < n; i++) {
        cout << "\n===== SINH VIEN " << (i+1) << " =====" << endl;
        SinhVien sv;
        nhapSinhVien(sv);
        ds.push_back(sv);
    }
}

// Hàm xuất thông tin 1 sinh viên
void xuatSinhVien(const SinhVien &sv) {
    cout << left << setw(12) << sv.mssv
         << setw(25) << sv.hoTen
         << right << fixed << setprecision(2)
         << setw(8) << sv.diem.toan
         << setw(8) << sv.diem.ly
         << setw(8) << sv.diem.hoa
         << setw(10) << sv.diemTrungBinh() << endl;
}

// Hàm xuất danh sách sinh viên
void xuatDanhSach(const vector<SinhVien> &ds) {
    if(ds.empty()) {
        cout << "\nDanh sach rong!" << endl;
        return;
    }
    
    cout << "\n===== DANH SACH SINH VIEN =====" << endl;
    cout << left << setw(12) << "MSSV"
         << setw(25) << "Ho Ten"
         << right << setw(8) << "Toan"
         << setw(8) << "Ly"
         << setw(8) << "Hoa"
         << setw(10) << "Diem TB" << endl;
    cout << string(75, '-') << endl;
    
    for(int i = 0; i < ds.size(); i++) {
        xuatSinhVien(ds[i]);
    }
}

// ===== CÂU 5b: SẮP XẾP THEO TIÊU CHÍ =====

// Hàm so sánh để sắp xếp
// Tiêu chí: Toán tăng dần -> Hóa tăng dần -> Lý tăng dần
bool soSanhSinhVien(const SinhVien &a, const SinhVien &b) {
    // So sánh điểm Toán trước
    if(a.diem.toan != b.diem.toan) {
        return a.diem.toan < b.diem.toan;
    }
    
    // Nếu Toán bằng nhau, so sánh điểm Hóa
    if(a.diem.hoa != b.diem.hoa) {
        return a.diem.hoa < b.diem.hoa;
    }
    
    // Nếu Hóa bằng nhau, so sánh điểm Lý
    return a.diem.ly < b.diem.ly;
}

// Hàm sắp xếp danh sách sinh viên
void sapXepDanhSach(vector<SinhVien> &ds) {
    sort(ds.begin(), ds.end(), soSanhSinhVien);
    cout << "\nDa sap xep danh sach theo tieu chi:" << endl;
    cout << "1. Diem Toan tang dan" << endl;
    cout << "2. Neu Toan bang nhau -> Hoa tang dan" << endl;
    cout << "3. Neu Hoa bang nhau -> Ly tang dan" << endl;
}

// ===== HÀM TẠO DỮ LIỆU MẪU =====
void taoDuLieuMau(vector<SinhVien> &ds) {
    ds.clear();
    
    SinhVien sv1 = {"SV001", "Nguyen Van An", {8.0, 7.5, 9.0}};
    SinhVien sv2 = {"SV002", "Tran Thi Binh", {8.0, 6.5, 9.0}};
    SinhVien sv3 = {"SV003", "Le Van Cuong", {7.0, 8.0, 6.5}};
    SinhVien sv4 = {"SV004", "Pham Thi Dung", {8.0, 6.5, 8.5}};
    SinhVien sv5 = {"SV005", "Hoang Van Em", {9.0, 7.0, 8.0}};
    
    ds.push_back(sv1);
    ds.push_back(sv2);
    ds.push_back(sv3);
    ds.push_back(sv4);
    ds.push_back(sv5);
    
    cout << "Da tao 5 sinh vien mau!" << endl;
}

// ===== MENU =====
void menu() {
    cout << "\n===== QUAN LY SINH VIEN =====" << endl;
    cout << "1. Nhap danh sach sinh vien" << endl;
    cout << "2. Xuat danh sach sinh vien" << endl;
    cout << "3. Sap xep sinh vien theo tieu chi" << endl;
    cout << "4. Tao du lieu mau" << endl;
    cout << "5. Tim sinh vien co diem TB cao nhat" << endl;
    cout << "6. Tim sinh vien co diem Toan cao nhat" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    vector<SinhVien> danhSach;
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1:
                nhapDanhSach(danhSach);
                break;
                
            case 2:
                xuatDanhSach(danhSach);
                break;
                
            case 3:
                sapXepDanhSach(danhSach);
                xuatDanhSach(danhSach);
                break;
                
            case 4:
                taoDuLieuMau(danhSach);
                xuatDanhSach(danhSach);
                break;
                
            case 5: {
                if(danhSach.empty()) {
                    cout << "Danh sach rong!" << endl;
                    break;
                }
                
                SinhVien svMax = danhSach[0];
                for(int i = 1; i < danhSach.size(); i++) {
                    if(danhSach[i].diemTrungBinh() > svMax.diemTrungBinh()) {
                        svMax = danhSach[i];
                    }
                }
                
                cout << "\nSinh vien co diem TB cao nhat:" << endl;
                cout << left << setw(12) << "MSSV"
                     << setw(25) << "Ho Ten"
                     << right << setw(8) << "Toan"
                     << setw(8) << "Ly"
                     << setw(8) << "Hoa"
                     << setw(10) << "Diem TB" << endl;
                cout << string(75, '-') << endl;
                xuatSinhVien(svMax);
                break;
            }
            
            case 6: {
                if(danhSach.empty()) {
                    cout << "Danh sach rong!" << endl;
                    break;
                }
                
                SinhVien svMax = danhSach[0];
                for(int i = 1; i < danhSach.size(); i++) {
                    if(danhSach[i].diem.toan > svMax.diem.toan) {
                        svMax = danhSach[i];
                    }
                }
                
                cout << "\nSinh vien co diem Toan cao nhat:" << endl;
                cout << left << setw(12) << "MSSV"
                     << setw(25) << "Ho Ten"
                     << right << setw(8) << "Toan"
                     << setw(8) << "Ly"
                     << setw(8) << "Hoa"
                     << setw(10) << "Diem TB" << endl;
                cout << string(75, '-') << endl;
                xuatSinhVien(svMax);
                break;
            }
            
            case 0:
                cout << "Tam biet!" << endl;
                break;
                
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

