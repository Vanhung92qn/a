// BÀI 1-2: TÍNH DIỆN TÍCH VÀ CHU VI CỦA HCN VÀ HÌNH TRÒN
#include <iostream>
#include <iomanip>
#define PI 3.14159265359
using namespace std;

// Hàm tính diện tích và chu vi HCN
void hinhChuNhat() {
    float dai, rong;
    cout << "\n=== HINH CHU NHAT ===" << endl;
    cout << "Nhap chieu dai: ";
    cin >> dai;
    cout << "Nhap chieu rong: ";
    cin >> rong;
    
    float dienTich = dai * rong;
    float chuVi = 2 * (dai + rong);
    
    cout << fixed << setprecision(2);
    cout << "Dien tich: " << dienTich << endl;
    cout << "Chu vi: " << chuVi << endl;
}

// Hàm tính diện tích và chu vi hình tròn
void hinhTron() {
    float banKinh;
    cout << "\n=== HINH TRON ===" << endl;
    cout << "Nhap ban kinh: ";
    cin >> banKinh;
    
    float dienTich = PI * banKinh * banKinh;
    float chuVi = 2 * PI * banKinh;
    
    cout << fixed << setprecision(2);
    cout << "Dien tich: " << dienTich << endl;
    cout << "Chu vi: " << chuVi << endl;
}

int main() {
    int luaChon;
    
    do {
        cout << "\n===== MENU =====" << endl;
        cout << "1. Tinh hinh chu nhat" << endl;
        cout << "2. Tinh hinh tron" << endl;
        cout << "0. Thoat" << endl;
        cout << "Lua chon: ";
        cin >> luaChon;
        
        switch(luaChon) {
            case 1:
                hinhChuNhat();
                break;
            case 2:
                hinhTron();
                break;
            case 0:
                cout << "Tam biet!" << endl;
                break;
            default:
                cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

