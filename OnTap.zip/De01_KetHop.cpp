// ĐỀ 1: BÀI TẬP KẾT HỢP
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <sstream>
using namespace std;

// ===== CÂU 1: KIỂM TRA NĂM NHUẬN =====
bool laNamNhuan(int nam) {
    return (nam % 400 == 0) || (nam % 4 == 0 && nam % 100 != 0);
}

void cau1() {
    int nam;
    cout << "Nhap nam: ";
    cin >> nam;
    
    if(laNamNhuan(nam)) {
        cout << nam << " la nam nhuan!" << endl;
    } else {
        cout << nam << " khong phai la nam nhuan!" << endl;
    }
}

// ===== CÂU 2: ĐẢO NGƯỢC SỐ NGUYÊN =====
long long daoNguocSo(long long n) {
    long long ketQua = 0;
    bool am = (n < 0);
    n = abs(n);
    
    while(n > 0) {
        ketQua = ketQua * 10 + n % 10;
        n /= 10;
    }
    
    return am ? -ketQua : ketQua;
}

void cau2() {
    long long n;
    cout << "Nhap so nguyen: ";
    cin >> n;
    
    cout << "So sau khi dao nguoc: " << daoNguocSo(n) << endl;
}

// ===== CÂU 3: MẢNG =====
const int MAX = 1000;
int M[MAX], n;

void nhapMang() {
    cout << "Nhap so phan tu: ";
    cin >> n;
    for(int i = 0; i < n; i++) {
        cout << "M[" << i << "] = ";
        cin >> M[i];
    }
}

void xuatMang() {
    cout << "Mang: ";
    for(int i = 0; i < n; i++) {
        cout << M[i] << " ";
    }
    cout << endl;
}

void chenPhanTu() {
    int x, k;
    cout << "Nhap gia tri can chen: ";
    cin >> x;
    cout << "Nhap vi tri (0-" << n << "): ";
    cin >> k;
    
    if(k < 0 || k > n) {
        cout << "Vi tri khong hop le!" << endl;
        return;
    }
    
    for(int i = n; i > k; i--) {
        M[i] = M[i-1];
    }
    M[k] = x;
    n++;
    cout << "Da chen " << x << " vao vi tri " << k << endl;
}

void sapXepTangDan() {
    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) {
            if(M[i] > M[j]) {
                swap(M[i], M[j]);
            }
        }
    }
    cout << "Da sap xep tang dan!" << endl;
}

void loaiGiaTriAm() {
    int j = 0;
    for(int i = 0; i < n; i++) {
        if(M[i] >= 0) {
            M[j++] = M[i];
        }
    }
    n = j;
    cout << "Da loai cac gia tri am!" << endl;
}

bool laSNT(int x) {
    if(x < 2) return false;
    if(x == 2) return true;
    if(x % 2 == 0) return false;
    for(int i = 3; i * i <= x; i += 2) {
        if(x % i == 0) return false;
    }
    return true;
}

void timSNTMax() {
    int maxSNT = -1;
    for(int i = 0; i < n; i++) {
        if(laSNT(M[i])) {
            if(maxSNT == -1 || M[i] > maxSNT) {
                maxSNT = M[i];
            }
        }
    }
    
    if(maxSNT == -1) {
        cout << "Khong co so nguyen to trong mang!" << endl;
    } else {
        cout << "So nguyen to lon nhat: " << maxSNT << endl;
    }
}

void tim2PhanTuTongMax() {
    if(n < 2) {
        cout << "Mang phai co it nhat 2 phan tu!" << endl;
        return;
    }
    
    int max1 = M[0], max2 = M[1];
    if(max1 < max2) swap(max1, max2);
    
    for(int i = 2; i < n; i++) {
        if(M[i] > max1) {
            max2 = max1;
            max1 = M[i];
        } else if(M[i] > max2) {
            max2 = M[i];
        }
    }
    
    cout << "2 phan tu co tong lon nhat: " << max1 << " va " << max2 << endl;
    cout << "Tong: " << (max1 + max2) << endl;
}

// ===== CÂU 4: CHUẨN HÓA CHUỖI =====
void chuanHoaTieuDe(string &s) {
    // Xóa khoảng trắng đầu cuối
    while(!s.empty() && s[0] == ' ') s.erase(0, 1);
    while(!s.empty() && s[s.length()-1] == ' ') s.erase(s.length()-1);
    
    // Xóa khoảng trắng thừa và viết hoa đầu từ
    string ketQua = "";
    bool dauTu = true;
    
    for(int i = 0; i < s.length(); i++) {
        if(s[i] != ' ') {
            if(dauTu) {
                ketQua += toupper(s[i]);
                dauTu = false;
            } else {
                ketQua += tolower(s[i]);
            }
        } else {
            if(!ketQua.empty() && ketQua[ketQua.length()-1] != ' ') {
                ketQua += ' ';
            }
            dauTu = true;
        }
    }
    
    s = ketQua;
}

void cau4() {
    cin.ignore();
    string s;
    cout << "Nhap chuoi: ";
    getline(cin, s);
    
    chuanHoaTieuDe(s);
    cout << "Chuoi sau khi chuan hoa: " << s << endl;
}

// ===== CÂU 5: ĐỌC FILE SINH VIÊN =====
struct SinhVien {
    string hoTen;
    int namSinh;
    float toan, ly, hoa;
    float diemTB;
    
    void tinhDiemTB() {
        diemTB = (toan + ly + hoa) / 3.0;
    }
};

void cau5() {
    ifstream fileIn("Input.txt");
    
    if(!fileIn) {
        cout << "Khong the mo file Input.txt!" << endl;
        return;
    }
    
    int soSV;
    fileIn >> soSV;
    
    vector<SinhVien> dsSV;
    
    for(int i = 0; i < soSV; i++) {
        SinhVien sv;
        fileIn >> sv.hoTen >> sv.namSinh >> sv.toan >> sv.ly >> sv.hoa;
        sv.tinhDiemTB();
        dsSV.push_back(sv);
    }
    
    fileIn.close();
    
    // Sắp xếp theo điểm TB tăng dần
    sort(dsSV.begin(), dsSV.end(), [](const SinhVien &a, const SinhVien &b) {
        return a.diemTB < b.diemTB;
    });
    
    // Hiển thị danh sách đã sắp xếp
    cout << fixed << setprecision(2);
    cout << "\n===== DANH SACH SINH VIEN (SAP XEP THEO DIEM TB) =====" << endl;
    cout << "Ho ten\t\tNam\tToan\tLy\tHoa\tTB" << endl;
    cout << "-----------------------------------------------------" << endl;
    
    for(int i = 0; i < dsSV.size(); i++) {
        cout << dsSV[i].hoTen << "\t"
             << dsSV[i].namSinh << "\t"
             << dsSV[i].toan << "\t"
             << dsSV[i].ly << "\t"
             << dsSV[i].hoa << "\t"
             << dsSV[i].diemTB << endl;
    }
    
    // Ghi sinh viên có điểm TB < 5 vào file
    ofstream fileOut("Output.txt");
    
    if(!fileOut) {
        cout << "Khong the tao file Output.txt!" << endl;
        return;
    }
    
    cout << "\n===== SINH VIEN CO DIEM TB < 5 =====" << endl;
    int dem = 0;
    
    for(int i = 0; i < dsSV.size(); i++) {
        if(dsSV[i].diemTB < 5) {
            fileOut << dsSV[i].hoTen << endl;
            fileOut << dsSV[i].namSinh << " " << dsSV[i].toan << " " 
                    << dsSV[i].ly << " " << dsSV[i].hoa << endl;
            
            cout << dsSV[i].hoTen << " - DTB: " << dsSV[i].diemTB << endl;
            dem++;
        }
    }
    
    fileOut.close();
    
    cout << "\nTong: " << dem << " sinh vien" << endl;
    cout << "Da ghi vao file Output.txt" << endl;
}

// ===== MENU =====
void menu() {
    cout << "\n===== DE 1: BAI TAP KET HOP =====" << endl;
    cout << "1. Cau 1: Kiem tra nam nhuan" << endl;
    cout << "2. Cau 2: Dao nguoc so nguyen" << endl;
    cout << "3. Cau 3a: Nhap mang" << endl;
    cout << "4. Cau 3b: Xuat mang" << endl;
    cout << "5. Cau 3c: Chen phan tu" << endl;
    cout << "6. Cau 3d: Sap xep tang dan" << endl;
    cout << "7. Cau 3e: Loai gia tri am" << endl;
    cout << "8. Cau 3f: Tim SNT lon nhat" << endl;
    cout << "9. Cau 3g: Tim 2 phan tu tong max" << endl;
    cout << "10. Cau 4: Chuan hoa chuoi tieu de" << endl;
    cout << "11. Cau 5: Doc file sinh vien" << endl;
    cout << "0. Thoat" << endl;
    cout << "Lua chon: ";
}

int main() {
    int luaChon;
    
    do {
        menu();
        cin >> luaChon;
        
        switch(luaChon) {
            case 1: cau1(); break;
            case 2: cau2(); break;
            case 3: nhapMang(); break;
            case 4: xuatMang(); break;
            case 5: chenPhanTu(); xuatMang(); break;
            case 6: sapXepTangDan(); xuatMang(); break;
            case 7: loaiGiaTriAm(); xuatMang(); break;
            case 8: timSNTMax(); break;
            case 9: tim2PhanTuTongMax(); break;
            case 10: cau4(); break;
            case 11: cau5(); break;
            case 0: cout << "Tam biet!" << endl; break;
            default: cout << "Lua chon khong hop le!" << endl;
        }
    } while(luaChon != 0);
    
    return 0;
}

